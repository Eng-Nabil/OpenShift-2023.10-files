![Global Enablement & Learning](https://gelgitlab.race.sas.com/GEL/utilities/writing-content-in-markdown/-/raw/master/img/gel_banner_logo_tech-partners.jpg)

# What Is New With The SAS Viya Platform on Red Hat OpenShift

* [Stable 2022.10 (Oct 2023) and LTS 2022.10 (Nov 2023)](#stable-202210-oct-2023-and-lts-202210-nov-2023)
* [Stable 2022.09 (Sept 2023)](#stable-202209-sept-2023)
* [Stable 2023.06 (June 2023)](#stable-202306-june-2023)
* [Stable 2023.05 (May 2023)](#stable-202305-may-2023)
* [Stable 2023.03 (March 2023) and LTS 2023.03 (May 2023)](#stable-202303-march-2023-and-lts-202303-may-2023)
* [Stable 2022.12 (Dec 2022)](#stable-202212-dec-2022)
* [Stable 2022.10 (Oct 2022)](#stable-202210-oct-2022)
* [Stable 2022.09 (Sept 2022) and LTS 2022.09 (Nov 2022)](#stable-202209-sept-2022-and-lts-202209-nov-2022)
* [Stable 2022.1.2 (June 2022)](#stable-202212-june-2022)
* [LTS 2022.1 (May 2022)](#lts-20221-may-2022)
* [Stable 2021.2.4 (Feb 2022)](#stable-202124-feb-2022)
* [LTS 2021.2 (Nov 2021)](#lts-20212-nov-2021)
* [Stable 2021.1.6 (Oct 2021)](#stable-202116-oct-2021)

## Stable 2022.10 (Oct 2023) and LTS 2022.10 (Nov 2023)

* The SAS Viya platform supports Red Hat OpenShift 4.12 - 4.14.

    _Support for OCP 4.14 has been added._

## Stable 2022.09 (Sept 2023)

* The SAS Viya platform supports Red Hat OpenShift 4.12 - 4.13.

    _Support for OCP 4.11 has been dropped._

* Expanded support for SAS Viya platform deployments on Red Hat OpenShift Container Platform (OCP).

    _Previous releases of the SAS Viya platform supported OCP only on VMWare 7.x._

## Stable 2023.06 (June 2023)

* This release adds support for GPUs on Red Hat OpenShift.

## Stable 2023.05 (May 2023)

* The SAS Viya platform supports Red Hat OpenShift 4.11 - 4.13 on VMWare 7.x.

   _Previous releases of the SAS Viya platform supported OCP 4.10 - 4.12._

* The combination of Red Hat OCP 4.13 and an internal instance of the PostgreSQL database is supported only with software assets downloaded after 12 July 2023.

    _Crunchy Data PostgreSQL, upon which internal PostgreSQL instances are based, adds support for OCP 4.13 starting with version 5.3.2, included with the SAS Viya platform starting on 12 July 2023._

## Stable 2023.03 (March 2023) and LTS 2023.03 (May 2023)

* The SAS Viya platform supports Red Hat OpenShift 4.10 - 4.12 on VMWare 7.x.

    _Previous releases of the SAS Viya platform supported OCP 4.9 - 4.11._

* The combination of Red Hat OCP 4.12 and an internal instance of the PostgreSQL database is supported only with software assets downloaded after 12 July 2023.

    _Crunchy Data PostgreSQL, upon which internal PostgreSQL instances are based, adds support for OCP 4.12 starting with version 5.3.2, included with the SAS Viya platform starting on 12 July 2023._

* SAS Mirror Manager now offers support for deploying from an image registry in Red Hat OpenShift.

## Stable 2022.12 (Dec 2022)

* You can deploy the SAS Viya platform with multi-tenancy on OpenShift starting with this release.

## Stable 2022.10 (Oct 2022)

* The SAS Viya platform supports Red Hat OpenShift 4.9 - 4.11 on VMWare 7.x.

    _Previous releases of the SAS Viya platform supported OCP 4.8 - 4.11._

* Updating to this version on OpenShift, when using the SAS-provided Crunchy Data PostgreSQL (a.k.a. internal PostgreSQL), is supported only with software assets downloaded after 17 January 2023 (no issues for fully new deployments).

* With the update to Crunchy Data 5, the SAS-provided PostgreSQL server no longer requires a custom SCC for deployments on Red Hat OpenShift.

## Stable 2022.09 (Sept 2022) and LTS 2022.09 (Nov 2022)

* The SAS Viya platform supports Red Hat OpenShift 4.8 - 4.11 on VMWare 7.x.

    _Previous releases of the SAS Viya platform supported OCP 4.8 - 4.10._

* SAS Visual Investigator is supported on OpenShift starting with this release.

## Stable 2022.1.2 (June 2022)

* The SAS Viya platform supports Red Hat OpenShift 4.8 - 4.10 on VMWare 7.x.

    _Previous releases of the SAS Viya platform supported OCP 4.7 - 4.9._

## LTS 2022.1 (May 2022)

* Support extended to Red Hat OpenShift 4.7 - 4.9 on VMWare 7.x.

    This has been backported to all supported stables, including 2021.2.5 and later.

## Stable 2021.2.4 (Feb 2022)

* SAS/CONNECT security context constraint is optional.

## LTS 2021.2 (Nov 2021)

* Added support for external instances of PostgreSQL.

## Stable 2021.1.6 (Oct 2021)

* SAS Viya platform on Red Hat OpenShift 4.7 on VMWare 7.x general availability.
