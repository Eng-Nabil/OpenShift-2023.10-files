![Global Enablement & Learning](https://gelgitlab.race.sas.com/GEL/utilities/writing-content-in-markdown/-/raw/master/img/gel_banner_logo_tech-partners.jpg)

# What Is New With This Workshop

* [January 2024](#january-2024)
* [December 2023](#december-2023)
* [October 2023](#october-2023)
* [January 2023](#january-2023)
* [November 2022](#november-2022)
* [October 2022](#october-2022)
* [August 2022](#august-2022)
* [Apr 2022](#apr-2022)
* [Feb 2022](#feb-2022)
* [Dec 2021](#dec-2021)

## January 2024

* Workshop is now based on **Red Hat OpenShift Container Platform 4.14**

## December 2023

* Workshop is now based on **SAS Viya LTS 2023.10**

## October 2023

* New Video: 04 062 Deployment Performing - Namespace Admin (7min) added
* Workshop is now based on Red Hat OpenShift 4.12 and SAS Viya LTS 2023.03
* Chapters have been split in smaller content units

## January 2023

* New chapter: 05_010 Temporary Storage
* 2 new exercises available:
    * 05_011_Provision_Temp_Storage
    * 05_012_Customize_CASDISKCACHE

## November 2022

* Workshop is now based on LTS release: SAS Viya LTS 2022.09

## October 2022

* Workshop updated to SAS Viya Stable 2022.09
* Added GEL_ReadyViya4 utility to check when SAS Viya is ready (04_025)

## August 2022

* Workshop updated to Red Hat OpenShift 4.10 and SAS Viya Stable 2022.1.4
* Workshop structure made easier to navigate
* New exercise 02_031 Explore OpenShift
* Added a workshop prerequisites section (01_010)
* New chapter OpenShift and Kubenetes (02_020)
* New considerations for CAS hostPath (03_020, 04_020)
* Workshop instructions changed to use openssl certificate generator (04_020)

## Apr 2022

* Hands-on Instructions updated to utilize new GELENABLE Azure tenant 
* Workshop upleveled to SAS Viya Stable 2021.2.6

## Feb 2022

* SAS/CONNECT security context constraint removed from Hands-on
* Workshop upleveled to SAS Viya Stable 2021.2.4

## Dec 2021

* Workshop initial release, based on SAS Viya Stable 2021.1.6 on Red Hat OpenShift 4.7