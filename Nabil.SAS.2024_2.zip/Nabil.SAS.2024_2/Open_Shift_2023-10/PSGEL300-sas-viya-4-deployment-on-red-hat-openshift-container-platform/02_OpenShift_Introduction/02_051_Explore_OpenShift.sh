OCP_API_URL="https://api.$(hostname -s).gelenable.sas.com:443"

echo "API_URL=${OCP_API_URL}" > ~/OCPurls.txt
cat ~/OCPurls.txt

# Save the OCP_API_URL info for next time we re-login
ansible localhost -m lineinfile \
  -a "dest=~/.bashrc \
      regexp='^export OCP_API_URL' \
      line='export OCP_API_URL=$(grep API_URL ~/OCPurls.txt | cut -d= -f2)'" \
      --diff
curl -k ${OCP_API_URL}/version
# when running with autodeploy, it takes up to 5 minutes for the OCP OAuth pods to accept LDAP logins
gatedemo003Pass=$(cat /home/cloud-user/azureADusers.txt|grep 'gatedemo003'|awk -F'::' '{print $2}')
timeout 900s bash -c "\
until \
oc login --insecure-skip-tls-verify --server $OCP_API_URL -u gatedemo003 -p "$gatedemo003Pass" ;\
do sleep 60; done"
oc whoami --show-console
