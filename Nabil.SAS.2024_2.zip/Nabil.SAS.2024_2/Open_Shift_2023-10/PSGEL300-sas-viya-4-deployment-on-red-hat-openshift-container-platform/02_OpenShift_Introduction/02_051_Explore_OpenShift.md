![Global Enablement & Learning](https://gelgitlab.race.sas.com/GEL/utilities/writing-content-in-markdown/-/raw/master/img/gel_banner_logo_tech-partners.jpg)

# Explore your OpenShift Container Platform cluster

* [Introduction](#introduction)
* [Find the address of your OpenShift cluster](#find-the-address-of-your-openshift-cluster)
* [Interact with OCP using the command line](#interact-with-ocp-using-the-command-line)
    * [Logon and set the CLI configuration file for the OCP cluster](#logon-and-set-the-cli-configuration-file-for-the-ocp-cluster)
    * [Familiarize with the CLI](#familiarize-with-the-cli)
* [Interact with OCP using the web console](#interact-with-ocp-using-the-web-console)
    * [Find the address of the web console](#find-the-address-of-the-web-console)
    * [Log into the OCP web console](#log-into-the-ocp-web-console)
* [Next Steps](#next-steps)
* [Complete Hands-on Navigation Index](#complete-hands-on-navigation-index)

## Introduction

In this workshop, we use an OpenShift Container Platform (OCP) cluster, which has been automatically installed on Azure and is dedicated for your use within this workshop.

The objective of this exercise is to learn how to interact with the OCP cluster, both with command-line tools and through the OpenShift web console.

## Find the address of your OpenShift cluster

To connect to your cluster you need the server API address. For this workshop we have configured it to be `https://api.<clientHostname>.gelenable.sas.com:443`. In a customer environment, a cluster administrator should give it to you.

1. Open the connection to sasnode01 in MobaXterm on the Windows client

1. Use the following commands to print the API address of your cluster and store it for later use

    ```bash
    OCP_API_URL="https://api.$(hostname -s).gelenable.sas.com:443"

    echo "API_URL=${OCP_API_URL}" > ~/OCPurls.txt
    cat ~/OCPurls.txt

    # Save the OCP_API_URL info for next time we re-login
    ansible localhost -m lineinfile \
      -a "dest=~/.bashrc \
          regexp='^export OCP_API_URL' \
          line='export OCP_API_URL=$(grep API_URL ~/OCPurls.txt | cut -d= -f2)'" \
          --diff
    ```

1. Verify that there are no firewalls blocking the connection, using the following command

    ```bash
    curl -k ${OCP_API_URL}/version
    ```

    This should be successful and print an output similar to the following:

    ```json
    {
    "major": "1",
    "minor": "27",
    "gitVersion": "v1.27.8+4fab27b",
    "gitCommit": "c7a50586071278562f15130ff5ba194015aedee2",
    "gitTreeState": "clean",
    "buildDate": "2023-12-01T15:11:39Z",
    "goVersion": "go1.20.10 X:strictfipsruntime",
    "compiler": "gc",
    "platform": "linux/amd64"
    }
    ```

## Interact with OCP using the command line

We will first learn how to interact wit the OpenShift cluster using the command-line

### Logon and set the CLI configuration file for the OCP cluster

The OpenShift CLI, `oc`, is a superset of `kubectl`: it supports all kubectl commands and options, plus it offers additional capabilities, specific to OpenShift.

Just as kubectl, to connect to a cluster it needs some configuration parameters, as options on the command-line or, better, in a kubeconfig file.

Just as with other kubernetes flavors, access to the OCP cluster requires proper credentials. For this cluster, we have configured the `gatedemo003` user to have full cluster administration rights.

1. Use the following command to fetch the `gatedemo003` user's password:

    ```sh
    echo "gatedemo003's password is: $(cat /home/cloud-user/azureADusers.txt|grep 'gatedemo003'|awk -F'::' '{print $2}')"
    ```

    You should see something like the following:

    ```log
    gatedemo003's password is: #########
    ```

1. Use the CLI to logon as `gatedemo003` with the password obtained above. This will create a valid kubeconfig file that will be used for any subsequent access to the cluster. At a customer site, a cluster administrator may provide you the required connection details, or, directly, a client kubeconfig already configured for use.

    ```sh
    oc login --server $OCP_API_URL -u gatedemo003
    ```

    You should be asked to confirm it's OK to use an unknown certificate output - enter `y`. Then the cli should ask to enter the password - enter the password obtained above.

    ```log
    [cloud-user@pdcesx03051 ~]$ $ oc login --server $OCP_API_URL -u gatedemo003
    The server uses a certificate signed by an unknown authority.
    You can bypass the certificate check, but any data you send to the server could be intercepted by others.
    Use insecure connections? (y/n): y

    WARNING: Using insecure TLS client config. Setting this option is not supported!

    Console URL: https://api.rext03-0273.gelenable.sas.com:443/console
    Authentication required for https://api.rext03-0273.gelenable.sas.com:443 (openshift)
    Username: gatedemo003
    Password:
    Login successful.

    You have access to 68 projects, the list has been suppressed. You can list all projects with 'oc projects'

    Using project "default".
    Welcome! See 'oc help' to get started.
    ```

1. Have a look at the kubeconfig that has been automatically created and verify that it is valid also for the regular `kubectl` cli:

    ```sh
    oc config view
    kubectl get ns
    ```

    You should see something like the following:

    ```log
    [cloud-user@pdcesx03051 ~]$ oc config view
    apiVersion: v1
    clusters:
    - cluster:
        insecure-skip-tls-verify: true
        server: https://api.pdcesx03051.gelenable.sas.com:443
    name: api-pdcesx03051-gelenable-sas-com:443
    contexts:
    - context:
        cluster: api-pdcesx03051-gelenable-sas-com:443
        namespace: default
        user: gatedemo003/api-pdcesx03051-gelenable-sas-com:443
    name: default/api-pdcesx03051-gelenable-sas-com:443/gatedemo003
    current-context: default/api-pdcesx03051-gelenable-sas-com:443/gatedemo003
    kind: Config
    preferences: {}
    users:
    - name: gatedemo003/api-pdcesx03051-gelenable-sas-com:443
    user:
        token: REDACTED
    [cloud-user@pdcesx03051 ~]$ kubectl get ns
    NAME                                               STATUS   AGE
    default                                            Active   3h17m
    kube-node-lease                                    Active   3h17m
    kube-public                                        Active   3h17m
    kube-system                                        Active   3h17m
    openshift                                          Active   3h8m
    ....
    ....
    openshift-vsphere-infra                            Active   3h16m
    ```

    If you look at the namespaces in the cluster (`kubectl get ns`) you should see all of the system ones: this is only possible because we are using an administrative identity as cluster administrators.

<!--
Auto-logon for the cheatcodes
```bash
# when running with autodeploy, it takes up to 5 minutes for the OCP OAuth pods to accept LDAP logins
gatedemo003Pass=$(cat /home/cloud-user/azureADusers.txt|grep 'gatedemo003'|awk -F'::' '{print $2}')
timeout 900s bash -c "\
  until \
    oc login --insecure-skip-tls-verify --server $OCP_API_URL -u gatedemo003 -p "$gatedemo003Pass" ;\
  do sleep 60; done"
```
-->

### Familiarize with the CLI

Now we will run some `oc` commands to familiarize with the environment and with the CLI, while checking the cluster. Remember, with most of the commands, you could use `kubectl` as well!

1. Check some connection details

    ```sh
    oc whoami
    oc whoami --show-server
    ```

    You should see output similar to the following:

    ```log
    [cloud-user@pdcesx03051 ~]$ oc whoami
    gatedemo003
    [cloud-user@pdcesx03051 ~]$ oc whoami --show-server
    https://api.pdcesx03051.gelenable.sas.com:443
    ```

1. Verify that all cluster nodes are ready:

    ```sh
    oc get nodes
    ```

    You should see output similar to the following:

    ```log
    NAME                            STATUS   ROLES    AGE   VERSION
    sasdemo-p03051-controlplane-0   Ready    master   50m   v1.27.8+4fab27b
    sasdemo-p03051-controlplane-1   Ready    master   50m   v1.27.8+4fab27b
    sasdemo-p03051-controlplane-2   Ready    master   50m   v1.27.8+4fab27b
    sasdemo-p03051-worker-1         Ready    worker   47m   v1.27.8+4fab27b
    sasdemo-p03051-worker-2         Ready    worker   47m   v1.27.8+4fab27b
    sasdemo-p03051-worker-3         Ready    worker   47m   v1.27.8+4fab27b
    sasdemo-p03051-worker-4         Ready    worker   47m   v1.27.8+4fab27b
    sasdemo-p03051-worker-5         Ready    worker   47m   v1.27.8+4fab27b
    ```

## Interact with OCP using the web console

Red Hat OpenShift Container Platform includes a web console that provides a graphical user interface to visualize and interact with your projects and perform administrative, management, and troubleshooting tasks. You see the nodes, pods, configuration, logs etc... very easily. You can also exec inside pods to debug issues.

The web console runs as pods on the control plane nodes in the openshift-console project.

### Find the address of the web console

You may have noticed that the address of the web console was printed during the initial logon to the OpenShift cluster.

1. Use the following commands to print it again:

    ```bash
    oc whoami --show-console
    ```

    You should see output similar to the following:

    ```log
    https://console-openshift-console.apps.pdcesx03051.gelenable.sas.com
    ```

### Log into the OCP web console

You can access the web console in two ways:

- CRTL+click on the console URL printed in the terminal.
- Select the *Red Hat OpenShift console* bookmark in Chrome.

On the log in page, select the **gelenable-adds** option, then log in with the same administrative account that we already used with the CLI: `gatedemo003` with the password obtained above.

![](img/OCPConsoleLogin.png)

You should be greeted by the Overview Home page

![](img/OCPConsoleHome.png)

Spend a few minutes browsing around the pages in the left pane to familiarize with the console.

The topmost drop down lets you switch between the **Administrator** and the **Developer** perspectives:

![](img/OCPConsolePerspectives.png)

For the sake of SAS Viya administration, we will only work in the Administrator perspective. The Developer one is mostly tailored to developers that deploy custom-made applications.

For additional information about the OCP web console, refer to Red Hat official documentation at <https://access.redhat.com/documentation/en-us/openshift_container_platform/4.14/html/web_console>

---

## Next Steps

**Congratulations ! You should now be connected to a running OCP cluster.**

Now that you can use the OCP cluster, the next exercise will perform the required prerequisites for Viya deployment.

Click [here](/04_Deployment/04_071_Perform_the_Prerequisites.md) to move onto the next exercise: ***04 071 Perform the Prerequisites***

---

## Complete Hands-on Navigation Index

<!-- startnav -->
* [01 Workshop Introduction / 01 031 Access the Environment](/01_Workshop_Introduction/01_031_Access_the_Environment.md)
* [01 Workshop Introduction / 01 032 Verify the Environment](/01_Workshop_Introduction/01_032_Verify_the_Environment.md)
* [01 Workshop Introduction / 01 999 Fast track with cheatcodes](/01_Workshop_Introduction/01_999_Fast_track_with_cheatcodes.md)
* [02 OpenShift Introduction / 02 051 Explore OpenShift](/02_OpenShift_Introduction/02_051_Explore_OpenShift.md)**<-- you are here**
* [04 Deployment / 04 071 Perform the Prerequisites](/04_Deployment/04_071_Perform_the_Prerequisites.md)
* [04 Deployment / 04 072 Prepare for Viya Deployment](/04_Deployment/04_072_Prepare_for_Viya_Deployment.md)
* [04 Deployment / 04 073 Prepare for OpenShift](/04_Deployment/04_073_Prepare_for_OpenShift.md)
* [04 Deployment / 04 074 Customize Viya Deployment](/04_Deployment/04_074_Customize_Viya_Deployment.md)
* [04 Deployment / 04 075 Manually Deploy Viya](/04_Deployment/04_075_Manually_Deploy_Viya.md)
* [05 Deployment Customizations / 05 021 Provision Temp Storage](/05_Deployment_Customizations/05_021_Provision_Temp_Storage.md)
* [05 Deployment Customizations / 05 022 Customize CASDISKCACHE](/05_Deployment_Customizations/05_022_Customize_CASDISKCACHE.md)
* [09 The End / 09 999 Cleanup](/09_The_End/09_999_Cleanup.md)
<!-- endnav -->
