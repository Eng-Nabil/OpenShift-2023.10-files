![Global Enablement & Learning](https://gelgitlab.race.sas.com/GEL/utilities/writing-content-in-markdown/-/raw/master/img/gel_banner_logo_tech-partners.jpg)

# Provision Temporary Storage

In this exercise we will walk through the steps required to provision temporary storage in the OpenShift cluster. The objective is to have dedicated storage that can be used for SAS and CAS working directories (SASWORK and CAS DISK CACHE).

* [Verify the current disk status](#verify-the-current-disk-status)
* [Prepare the temporary disk](#prepare-the-temporary-disk)
* [Deploy the Local Storage Operator](#deploy-the-local-storage-operator)
* [Provision local storage using the Local Storage Operator](#provision-local-storage-using-the-local-storage-operator)
    * [Create a Local Volume](#create-a-local-volume)
    * [Verify the automatically created artifacts](#verify-the-automatically-created-artifacts)
* [Test the newly referenced local storage](#test-the-newly-referenced-local-storage)
    * [Create a Persistent Volume Claim](#create-a-persistent-volume-claim)
    * [Start a test container to verify local storage](#start-a-test-container-to-verify-local-storage)
* [Next Steps](#next-steps)
* [Complete Hands-on Navigation Index](#complete-hands-on-navigation-index)

## Verify the current disk status

Our environment is using the Azure cloud as the underlying infrastructure. All the virtual machines used by the OpenShift cluster have an internal SSD drive that could be used to host SAS temporary storage. These disks are currently not used: they are not even mounted to be visible to the underlying OS.

1. Verify the disks available on the first worker node using [OpenShift debug capabilities](https://www.redhat.com/sysadmin/how-oc-debug-works) and the [lsblk command](https://man7.org/linux/man-pages/man8/lsblk.8.html):

    ```sh
    # Find the 1st worker node's name
    WORKER=$(oc get nodes -l "node-role.kubernetes.io/worker" -o name | head -1)
    echo ${WORKER}
    # Query disk status using the lsblk command in a debug session on the node
    oc debug ${WORKER}
     # now we are in the debug container
     chroot /host
     lsblk -o NAME,SIZE,FSTYPE,LABEL,MOUNTPOINT
     # exit the debug container
     exit
     exit

    ```

    You should get a listing similar to the following:

    ```log
    $ # Find the 1st worker node's name
    $ WORKER=$(oc get nodes -l "node-role.kubernetes.io/worker" -o name | head -1)
    $ echo ${WORKER}
    node/itaedr-r-0097-worker-1
    $ # Query disk status using the lsblk command in a debug session on the node
    $ oc debug ${WORKER}
    Starting pod/itaedr-r-0097-worker-1-debug ...
    To use host binaries, run `chroot /host`
    Pod IP: 10.255.1.8
    If you don't see a command prompt, try pressing enter.
    sh-4.4#  # now we are in the debug container
    sh-4.4#  chroot /host
    sh-4.4#  lsblk -o NAME,SIZE,FSTYPE,LABEL,MOUNTPOINT
    NAME     SIZE FSTYPE LABEL             MOUNTPOINT
    sda      128G
    |-sda1     1M
    |-sda2   127M vfat   EFI-SYSTEM
    |-sda3   384M ext4   boot              /boot
    `-sda4 127.5G xfs    root              /sysroot
    sdb      300G
    `-sdb1   300G ntfs   Temporary Storage
    sdc        1G ext4                     /var/lib/kubelet/pods/08cef6f4-8032-449d-bcea-309355cb383c/volumes/kubernetes.io~azure-disk/pvc-fa675cfb-cd0d-49e6-843e-44adec80241f
    sr0
    sh-4.4#  # exit the debug container
    sh-4.4#  exit
    exit
    sh-4.4#  exit
    exit

    Removing debug pod ...
    ```

    From this output we can understand what disks are available to this node - and to the pods running there.

    * The first disk is `sda`. This has some partitions mounted on the node OS. In the above output, `sda4` is the OS root, that is seen by the debug pod as /sysroot. The disk size is 128GB, which corresponds to what was requested when the Azure virtual machine was created (by the workshop scripts).
    * The second disk is `sdb` and is not mounted. It contains a single partition `sdb1`; from its label **Temporary Storage** we can understand that this is the [temporary disk](https://learn.microsoft.com/en-us/azure/virtual-machines/managed-disks-overview#temporary-disk) that Azure provides. Its size depends on the virtual machine type used to instantiate this node (Not all Azure machine types include a temporary disk!)

      &#128073; Note that this disk, although currently not used, contains a partition of type **ntfs**, which is a Windows filesystem.
    * There can be additional disks; these are is dynamically created by OpenShift as requested by running pods PVCs. This is specific to our environment, since our default storage class is _managed-premium(Azure disk)_, as we have seen in exercise [04_021](../04_Deployment/04_021_Perform_the_Prerequisites.md#verify-that-the-cluster-has-the-correct-storage).

        In the example above, `sdc` is a 1GB disk mounted on the pod with id _08cef6f4-8032-449d-bcea-309355cb383c_ as a volume named _pvc-fa675cfb-cd0d-49e6-843e-44adec80241f_

    > &#128073; Note: In your results, `sda` and `sdb` may be switched, because [linux does not guarantee the order](https://learn.microsoft.com/en-us/troubleshoot/azure/virtual-machines/troubleshoot-device-names-problems) in which disks are configured at boot time.

## Prepare the temporary disk

As we has seen above, the temporary disk, although currently not used, contains a partition of type **ntfs**, which is a Windows file system. In the next steps we are going to use tools that expect/support Linux file systems. Since this is a temporary empty partition, we can overwrite it and create a new empty partition with a Linux **xfs** file system.

1. Run the following code to use the OpenShift debug container on all worker nodes to re-format the temporary partition with an xfs file system:

    ```bash
    # fix the partition on the temporary disk on all worker nodes
    AZURE_TMP_DEV=/host/dev/disk/azure/resource
    for _NODE in $(oc get nodes -l node-role.kubernetes.io/worker -o name); do
      # run inside the debug privileged container
      oc debug -q ${_NODE} -- bash -c "\
        parted ${AZURE_TMP_DEV} --script -- \
          mklabel gpt \
          mkpart xfs 1MiB -2048s ;\
        sleep 15;\
        lsblk ${AZURE_TMP_DEV};\
        mkfs -t xfs -f ${AZURE_TMP_DEV}-part1 \
      "
    done
    ```

    <details><summary>Click here to see the expected output</summary>

    ```log
    $ for _NODE in $(oc get nodes -l node-role.kubernetes.io/worker -o name); do
    >   # run inside the debug privileged container
    >   oc debug -q ${_NODE} -- bash -c "\
    >     parted ${AZURE_TMP_DEV} --script -- \
    >       mklabel gpt \
    >       mkpart xfs 1MiB -2048s ;\
    >     sleep 15;\
    >     lsblk ${AZURE_TMP_DEV};\
    >     mkfs -t xfs -f ${AZURE_TMP_DEV}-part1 \
    >   "
    > done
    NAME   MAJ:MIN RM  SIZE RO TYPE MOUNTPOINT
    sdb      8:16   0  300G  0 disk
    `-sdb1   8:17   0  300G  0 part
    meta-data=/host/dev/disk/azure/resource-part1 isize=512    agcount=4, agsize=19660672 blks
            =                       sectsz=4096  attr=2, projid32bit=1
            =                       crc=1        finobt=1, sparse=1, rmapbt=0
            =                       reflink=1
    data     =                       bsize=4096   blocks=78642688, imaxpct=25
            =                       sunit=0      swidth=0 blks
    naming   =version 2              bsize=4096   ascii-ci=0, ftype=1
    log      =internal log           bsize=4096   blocks=38399, version=2
            =                       sectsz=4096  sunit=1 blks, lazy-count=1
    realtime =none                   extsz=4096   blocks=0, rtextents=0
    Discarding blocks...Done.
    NAME   MAJ:MIN RM  SIZE RO TYPE MOUNTPOINT
    sda      8:0    0  300G  0 disk
    `-sda1   8:1    0  300G  0 part
    meta-data=/host/dev/disk/azure/resource-part1 isize=512    agcount=4, agsize=19660672 blks
            =                       sectsz=4096  attr=2, projid32bit=1
            =                       crc=1        finobt=1, sparse=1, rmapbt=0
            =                       reflink=1
    data     =                       bsize=4096   blocks=78642688, imaxpct=25
            =                       sunit=0      swidth=0 blks
    naming   =version 2              bsize=4096   ascii-ci=0, ftype=1
    log      =internal log           bsize=4096   blocks=38399, version=2
            =                       sectsz=4096  sunit=1 blks, lazy-count=1
    realtime =none                   extsz=4096   blocks=0, rtextents=0
    Discarding blocks...Done.
    NAME   MAJ:MIN RM  SIZE RO TYPE MOUNTPOINT
    sda      8:0    0  300G  0 disk
    `-sda1   8:1    0  300G  0 part
    meta-data=/host/dev/disk/azure/resource-part1 isize=512    agcount=4, agsize=19660672 blks
            =                       sectsz=4096  attr=2, projid32bit=1
            =                       crc=1        finobt=1, sparse=1, rmapbt=0
            =                       reflink=1
    data     =                       bsize=4096   blocks=78642688, imaxpct=25
            =                       sunit=0      swidth=0 blks
    naming   =version 2              bsize=4096   ascii-ci=0, ftype=1
    log      =internal log           bsize=4096   blocks=38399, version=2
            =                       sectsz=4096  sunit=1 blks, lazy-count=1
    realtime =none                   extsz=4096   blocks=0, rtextents=0
    Discarding blocks...Done.
    NAME   MAJ:MIN RM  SIZE RO TYPE MOUNTPOINT
    sda      8:0    0  300G  0 disk
    `-sda1   8:1    0  300G  0 part
    meta-data=/host/dev/disk/azure/resource-part1 isize=512    agcount=4, agsize=19660672 blks
            =                       sectsz=4096  attr=2, projid32bit=1
            =                       crc=1        finobt=1, sparse=1, rmapbt=0
            =                       reflink=1
    data     =                       bsize=4096   blocks=78642688, imaxpct=25
            =                       sunit=0      swidth=0 blks
    naming   =version 2              bsize=4096   ascii-ci=0, ftype=1
    log      =internal log           bsize=4096   blocks=38399, version=2
            =                       sectsz=4096  sunit=1 blks, lazy-count=1
    realtime =none                   extsz=4096   blocks=0, rtextents=0
    Discarding blocks...Done.
    NAME   MAJ:MIN RM  SIZE RO TYPE MOUNTPOINT
    sdb      8:16   0  300G  0 disk
    `-sdb1   8:17   0  300G  0 part
    meta-data=/host/dev/disk/azure/resource-part1 isize=512    agcount=4, agsize=19660672 blks
            =                       sectsz=4096  attr=2, projid32bit=1
            =                       crc=1        finobt=1, sparse=1, rmapbt=0
            =                       reflink=1
    data     =                       bsize=4096   blocks=78642688, imaxpct=25
            =                       sunit=0      swidth=0 blks
    naming   =version 2              bsize=4096   ascii-ci=0, ftype=1
    log      =internal log           bsize=4096   blocks=38399, version=2
            =                       sectsz=4096  sunit=1 blks, lazy-count=1
    realtime =none                   extsz=4096   blocks=0, rtextents=0
    Discarding blocks...Done.
    ```

    </details>

    Within the previous commands we are using a trick to overcome the issue that, on some nodes, the temporary disk is `sdb`, while on other nodes it is `sda`: the node OS automatically creates a link called `/dev/disk/azure/resource` that points to the correct disk, and another link called `/dev/disk/azure/resource-part1` that points to the first partition inside that disk. To use them inside the OpenShift debug container, we have to prefix `/host` to these paths.

## Deploy the Local Storage Operator

To leverage the Azure temporary disks, it is possible to manually create [local Volumes](https://kubernetes.io/docs/concepts/storage/volumes/#local) using standard Kubernetes practices, but that would require the cluster administrator to fully manage lower-level [storage lifecycle operations](https://github.com/kubernetes-sigs/sig-storage-local-static-provisioner/blob/master/docs/operations.md).

OpenShift simplifies local storage management thanks to the [**Local Storage Operator**](https://docs.openshift.com/container-platform/4.14/storage/persistent_storage/persistent_storage_local/persistent-storage-local.html).

This operator is not installed by default. We will install the **Local Storage Operator** following [RedHat instructions](https://docs.openshift.com/container-platform/4.14/storage/persistent_storage/persistent_storage_local/persistent-storage-local.html#local-storage-install_persistent-storage-local) using the OperatorHub from the web console.

1. Logon to the OpenShift web console with the cluster-admin role `gatedemo003`

1. In the Administrator view, open the **Operators** menu, select the **OperatorHub** page, enter `Local Storage` in the filter, and click on the resulting `Local Storage` box.

    ![](img/OperatorHub_LocalStorage.png)

1. Select **Install**, then accept all defaults and select **Install**.

    ![](img/LocalStorageInstall1.png)

1. The installation will start; it may take up to 5 minutes to complete. At the end you should get a green checkmark; select **View Operator** to verify it is actually running.

    ![](img/LocalStorageInstall2.png)

<!--
# Auto-deploy for the cheatcodes
# Instructions from https://docs.openshift.com/container-platform/4.14/storage/persistent_storage/persistent_storage_local/persistent-storage-local.html
```bash
BASEDIR=/home/cloud-user/PSGEL300-sas-viya-4-deployment-on-red-hat-openshift-container-platform
oc apply -f ${BASEDIR}/assets/OCP/localStorageOperator.yaml
# Wait for Custom Resource to be deployed
# fix Issue #46
timeout 300 bash -c "while ! kubectl wait --for condition=established --timeout=180s crd localvolumes.local.storage.openshift.io 2>/dev/null; do sleep 10; echo -n .; done"
```
-->

## Provision local storage using the Local Storage Operator

### Create a Local Volume

We can now use the Local Storage Operator to provision local storage for SAS Viya pods. The operator can create Persistent Volumes by looking for available file systems at the paths specified in a Local Volume object.

1. Create the yaml file describing the Local Volume object:

    ```bash
    cat > ~/project/storage/localVolume.yaml <<-EOF
    apiVersion: "local.storage.openshift.io/v1"
    kind: "LocalVolume"
    metadata:
      name: "lv-sastmp"
      namespace: "openshift-local-storage"
    spec:
      storageClassDevices:
        - storageClassName: "sastmp"
          volumeMode: Filesystem
          fsType: xfs
          devicePaths:
            - /dev/disk/azure/resource-part1
    EOF
    ```

    Note that, in this environment, we want the Local Volume to be available on all worker nodes (OpenShift controller nodes are excluded by default). If you wanted to use a subset of nodes, i.e. only the SAS CAS nodes, you could specify a nodeSelector. As an example, you could filter on the `workload.sas.com/class=cas` label:

    ```yaml
    apiVersion: "local.storage.openshift.io/v1"
    kind: "LocalVolume"
    metadata:
      name: "lv-sastmp"
      namespace: "openshift-local-storage"
    spec:
      nodeSelector:
        nodeSelectorTerms:
        - matchExpressions:
          - key: workload.sas.com/class
            operator: In
            values:
            - cas
      storageClassDevices:
        - storageClassName: "sastmp"
          volumeMode: Filesystem
          fsType: xfs
          devicePaths:
            - /dev/disk/azure/resource-part1
    ```

1. Create the resource in the OpenShift cluster:

    ```bash
    oc apply -f ~/project/storage/localVolume.yaml
    ```

    You should get a confirmation message:

    ```log
    localvolume.local.storage.openshift.io/lv-sastmp created
    ```

### Verify the automatically created artifacts

The operator should automatically create the storage class referenced in the Local Volume, if it did not already exist. Then, it should start a pod to manage the storage on each node. Finally, it should create a Persistent Volume for each disk discovered on each node.

1. Verify that the operator has created the storage class with the name we specified, `sastmp`:

    ```sh
    oc get sc sastmp
    ```

    You should get an output similar to the following:

    ```log
    $ oc get sc sastmp
    NAME       PROVISIONER                    RECLAIMPOLICY   VOLUMEBINDINGMODE      ALLOWVOLUMEEXPANSION   AGE
    sastmp     kubernetes.io/no-provisioner   Delete          WaitForFirstConsumer   false                  1m45s
    ```

    If you required different settings, such as VolumeBindingMode=Immediate, then you should manually create the Storage Class before using it in the Local Volume.

1. Verify that deamonset pods that implement the local storage provisioner are running :

    ```sh
    oc get daemonsets,pods -n openshift-local-storage
    ```

    You should get an output similar to the following.

    ```log
    $ oc get daemonsets,pods -n openshift-local-storage
    NAME                               DESIRED   CURRENT   READY   UP-TO-DATE   AVAILABLE   NODE SELECTOR   AGE
    daemonset.apps/diskmaker-manager   5         5         5       5            5           <none>          3m12s

    NAME                                          READY   STATUS    RESTARTS   AGE
    pod/diskmaker-manager-7z7gx                   2/2     Running   0          3m12s
    pod/diskmaker-manager-m7zv6                   2/2     Running   0          3m12s
    pod/diskmaker-manager-vdgfk                   2/2     Running   0          3m12s
    pod/diskmaker-manager-xxwpp                   2/2     Running   0          3m12s
    pod/diskmaker-manager-zwdjt                   2/2     Running   0          3m12s
    pod/local-storage-operator-7f7c469c5f-zqbnp   1/1     Running   0          15m
    ```

    Note that there are 5 _diskmaker-manager_ pods, one per node. It may take a couple of minutes for the pods to become Running, so, if you do not see them, wait and try again the previous command.

1. Verify that the operator has created multiple Persistent Volumes (PV), one for each node:

    ```sh
    oc get pv -l storage.openshift.com/owner-kind=LocalVolume
    ```

    You should get an output similar to the following:

    ```log
    $ oc get pv -l storage.openshift.com/owner-kind=LocalVolume
    NAME                CAPACITY   ACCESS MODES   RECLAIM POLICY   STATUS      CLAIM   STORAGECLASS   REASON   AGE
    local-pv-16d03346   299Gi      RWO            Delete           Available           sastmp                  8m49s
    local-pv-3d8b261f   299Gi      RWO            Delete           Available           sastmp                  8m25s
    local-pv-9b1ee482   299Gi      RWO            Delete           Available           sastmp                  8m48s
    local-pv-9d399c49   299Gi      RWO            Delete           Available           sastmp                  8m25s
    local-pv-d709a537   299Gi      RWO            Delete           Available           sastmp                  8m25s
    ```

    It may take a minute or two for the PVs to appear; if the list is still empty when you retry the command after one ot two minutes, then something may be wrong within the LocalVolume yaml definition. In that case, remove it with the following command, then check it and retry.

    ```sh
    # uncomment and submit the following to remove the LocalVolume definition
    #oc delete -f ~/project/storage/localVolume.yaml
    ```

## Test the newly referenced local storage

It's always a good practice to test your infrastructure before using it in SAS Viya.

Local volumes are accessed by pods through Persistent Volume Claims (PVCs). Statically-created PVCs will remain pending until the first pod tries to use them.

Let's create a PVC that references our local volumes, and a pod to test the storage.

### Create a Persistent Volume Claim

1. Define a PVC that uses the `sastmp` storage class

    ```bash
    cat > ~/project/storage/localPVC.yaml <<-EOF
    kind: PersistentVolumeClaim
    apiVersion: v1
    metadata:
      name: localpvc-sastmp
    spec:
      accessModes:
      - ReadWriteOnce
      volumeMode: Filesystem
      resources:
        requests:
          storage: 100Gi
      storageClassName: sastmp
    EOF
    ```

1. Create the resource in the OpenShift cluster. PVCs should be in the same namespace as the pods that will use them, so we specify the SAS Viya one:

    ```bash
    oc apply -f ~/project/storage/localPVC.yaml -n gel-viya
    ```

    You should get a confirmation message:

    ```log
    persistentvolumeclaim/localpvc-sastmp created
    ```

### Start a test container to verify local storage

1. Define a test pod

    ```bash
    cat > ~/project/storage/localStorageTest.yaml <<-EOF
    ---
    kind: Pod
    apiVersion: v1
    metadata:
      name: gel-test-pod
    spec:
      containers:
      - name: gel-test-pod
        image: gcr.io/google_containers/busybox:1.27
        command:
          - "/bin/sh"
        args:
          - "-c"
          - "df -h | grep sd && touch /sastmp/SUCCESS && ls -l /sastmp/SUCCESS && exit 0 || exit 1"
        volumeMounts:
          - name: sastmp
            mountPath: "/sastmp"
      restartPolicy: "Never"
      volumes:
        - name: sastmp
          persistentVolumeClaim:
            claimName: localpvc-sastmp
    EOF
    ```

    You can see that we reference the PVC just created (localpvc-sastmp) and mount it at the `/sastmp` path inside the container, so that some test commands can read and write from that location.

1. Create the resource in the OpenShift cluster:

    ```bash
    oc apply -f ~/project/storage/localStorageTest.yaml -n gel-viya
    ```

    You should get a confirmation message:

    ```log
    pod/gel-test-pod created
    ```

1. Check the successful allocation of the disk:

    ```bash
    # Wait up to 1 minute for pod to be finished
    kubectl wait --for jsonpath='{.status.phase}'=Succeeded --timeout=60s pod gel-test-pod
    oc logs gel-test-pod -n gel-viya
    ```

    You should get a listing similar to the following:

    ```log
    $ oc logs gel-test-pod  -n gel-viya
    /dev/sdb1               299.9G      2.1G    297.7G   1% /sastmp
    /dev/sda4               127.5G      9.2G    118.3G   7% /etc/hosts
    /dev/sda4               127.5G      9.2G    118.3G   7% /dev/termination-log
    -rw-r--r--    1 root     root             0 Jan 13 23:31 /sastmp/SUCCESS
    ```

    You should see that the ~300GB disk has been mounted at the `/sastmp` path as requested, and the pod was able to successfully write there a test file called `SUCCESS`.

    Note that, just as above, the `sdb` and `sda` disks could be listed switched.

1. Remove the test artifacts :

    ```bash
    oc delete pod gel-test-pod -n gel-viya
    oc delete pvc localpvc-sastmp -n gel-viya
    ```

    You should get a confirmation message:

    ```log
    pod "gel-test-pod" deleted
    persistentvolumeclaim "localpvc-sastmp" deleted
    ```

---

## Next Steps

At this point, you have prepared and tested the additional available storage.
The next step is to use it in your SAS Viya environment.

Click [here](/05_Deployment_Customizations/05_022_Customize_CASDISKCACHE.md) to move onto the next exercise: ***05 022 Customize_CASDISKCACHE***

---

## Complete Hands-on Navigation Index
<!-- startnav -->
* [01 Workshop Introduction / 01 031 Access the Environment](/01_Workshop_Introduction/01_031_Access_the_Environment.md)
* [01 Workshop Introduction / 01 032 Verify the Environment](/01_Workshop_Introduction/01_032_Verify_the_Environment.md)
* [01 Workshop Introduction / 01 999 Fast track with cheatcodes](/01_Workshop_Introduction/01_999_Fast_track_with_cheatcodes.md)
* [02 OpenShift Introduction / 02 051 Explore OpenShift](/02_OpenShift_Introduction/02_051_Explore_OpenShift.md)
* [04 Deployment / 04 071 Perform the Prerequisites](/04_Deployment/04_071_Perform_the_Prerequisites.md)
* [04 Deployment / 04 072 Prepare for Viya Deployment](/04_Deployment/04_072_Prepare_for_Viya_Deployment.md)
* [04 Deployment / 04 073 Prepare for OpenShift](/04_Deployment/04_073_Prepare_for_OpenShift.md)
* [04 Deployment / 04 074 Customize Viya Deployment](/04_Deployment/04_074_Customize_Viya_Deployment.md)
* [04 Deployment / 04 075 Manually Deploy Viya](/04_Deployment/04_075_Manually_Deploy_Viya.md)
* [05 Deployment Customizations / 05 021 Provision Temp Storage](/05_Deployment_Customizations/05_021_Provision_Temp_Storage.md)**<-- you are here**
* [05 Deployment Customizations / 05 022 Customize CASDISKCACHE](/05_Deployment_Customizations/05_022_Customize_CASDISKCACHE.md)
* [09 The End / 09 999 Cleanup](/09_The_End/09_999_Cleanup.md)
<!-- endnav -->
