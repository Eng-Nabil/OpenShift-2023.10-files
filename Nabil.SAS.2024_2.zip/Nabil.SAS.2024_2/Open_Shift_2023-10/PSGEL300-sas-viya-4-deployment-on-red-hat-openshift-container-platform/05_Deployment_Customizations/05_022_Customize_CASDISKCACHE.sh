cp -rp ~/project/gelocp ~/project/gelocp-custom
mv ~/project/gelocp-custom/site.yaml ~/project/gelocp-custom/site.yaml.orig
cat > ~/project/gelocp-custom/site-config/cas_disk_cache-config.yaml <<-EOF
# # this defines the volume and volumemount for CAS DISK CACHE location
---
apiVersion: builtin
kind: PatchTransformer
metadata:
  name: cas-cache-hostpath
patch: |-
  - op: add
    path: /spec/controllerTemplate/spec/volumes/-
    value:
      name: cas-cache-sastmp
      ephemeral:
        volumeClaimTemplate:
          spec:
            accessModes: [ "ReadWriteOnce" ]
            storageClassName: "sastmp"
            resources:
              requests:
                storage: 100Gi
  - op: add
    path: /spec/controllerTemplate/spec/containers/0/volumeMounts/-
    value:
      name: cas-cache-sastmp
      mountPath: /cas/cache-sastmp # # mountPath is the path inside the pod that CAS will reference
  - op: add
    path: /spec/controllerTemplate/spec/containers/0/env/-
    value:
      name: CASENV_CAS_DISK_CACHE
      value: "/cas/cache-sastmp" # # This has to match the value that is inside the pod
target:
  version: v1alpha1
  group: viya.sas.com
  kind: CASDeployment
  # # Target filtering: chose/uncomment one of these option:
  # #    To target only the default CAS server (cas-shared-default) :
  labelSelector: "sas.com/cas-server-default"
  # #    To target only a single CAS server (e.g. MyCAS) other than default:
  # name: {{MyCAS}}
  # #    To target all CAS Servers
  # name: .*
EOF
sed -i '/cas_disk_cache-config.yaml/d' ~/project/gelocp-custom/kustomization.yaml; \
sed -i '/.*update-fsgroup.yaml/a\ \ -\ site-config/cas_disk_cache-config.yaml' ~/project/gelocp-custom/kustomization.yaml
cd ~/project/gelocp-custom/
kustomize build -o site.yaml
oc apply -n gel-viya --selector="sas.com/admin=namespace" -f site.yaml --prune
oc -n gel-viya delete pods -l app.kubernetes.io/managed-by=sas-cas-operator
oc get scc sas-cas-server -o jsonpath='{.volumes}'
oc -n gel-viya get scc sas-cas-server -o json | jq '.volumes += ["ephemeral"]' | oc -n gel-viya apply -f -
oc get scc sas-cas-server -o jsonpath='{.volumes}'
# wait 30 seconds
sleep 30
oc -n gel-viya get pods -l app.kubernetes.io/managed-by=sas-cas-operator
kubectl wait --for=condition=Ready  --timeout=300s pod  -l app.kubernetes.io/managed-by=sas-cas-operator
