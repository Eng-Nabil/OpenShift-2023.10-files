# fix the partition on the temporary disk on all worker nodes
AZURE_TMP_DEV=/host/dev/disk/azure/resource
for _NODE in $(oc get nodes -l node-role.kubernetes.io/worker -o name); do
  # run inside the debug privileged container
  oc debug -q ${_NODE} -- bash -c "\
    parted ${AZURE_TMP_DEV} --script -- \
      mklabel gpt \
      mkpart xfs 1MiB -2048s ;\
    sleep 15;\
    lsblk ${AZURE_TMP_DEV};\
    mkfs -t xfs -f ${AZURE_TMP_DEV}-part1 \
  "
done
BASEDIR=/home/cloud-user/PSGEL300-sas-viya-4-deployment-on-red-hat-openshift-container-platform
oc apply -f ${BASEDIR}/assets/OCP/localStorageOperator.yaml
# Wait for Custom Resource to be deployed
# fix Issue #46
timeout 300 bash -c "while ! kubectl wait --for condition=established --timeout=180s crd localvolumes.local.storage.openshift.io 2>/dev/null; do sleep 10; echo -n .; done"
cat > ~/project/storage/localVolume.yaml <<-EOF
apiVersion: "local.storage.openshift.io/v1"
kind: "LocalVolume"
metadata:
  name: "lv-sastmp"
  namespace: "openshift-local-storage"
spec:
  storageClassDevices:
    - storageClassName: "sastmp"
      volumeMode: Filesystem
      fsType: xfs
      devicePaths:
        - /dev/disk/azure/resource-part1
EOF
oc apply -f ~/project/storage/localVolume.yaml
cat > ~/project/storage/localPVC.yaml <<-EOF
kind: PersistentVolumeClaim
apiVersion: v1
metadata:
  name: localpvc-sastmp
spec:
  accessModes:
  - ReadWriteOnce
  volumeMode: Filesystem
  resources:
    requests:
      storage: 100Gi
  storageClassName: sastmp
EOF
oc apply -f ~/project/storage/localPVC.yaml -n gel-viya
cat > ~/project/storage/localStorageTest.yaml <<-EOF
---
kind: Pod
apiVersion: v1
metadata:
  name: gel-test-pod
spec:
  containers:
  - name: gel-test-pod
    image: gcr.io/google_containers/busybox:1.27
    command:
      - "/bin/sh"
    args:
      - "-c"
      - "df -h | grep sd && touch /sastmp/SUCCESS && ls -l /sastmp/SUCCESS && exit 0 || exit 1"
    volumeMounts:
      - name: sastmp
        mountPath: "/sastmp"
  restartPolicy: "Never"
  volumes:
    - name: sastmp
      persistentVolumeClaim:
        claimName: localpvc-sastmp
EOF
oc apply -f ~/project/storage/localStorageTest.yaml -n gel-viya
# Wait up to 1 minute for pod to be finished
kubectl wait --for jsonpath='{.status.phase}'=Succeeded --timeout=60s pod gel-test-pod
oc logs gel-test-pod -n gel-viya
oc delete pod gel-test-pod -n gel-viya
oc delete pvc localpvc-sastmp -n gel-viya
