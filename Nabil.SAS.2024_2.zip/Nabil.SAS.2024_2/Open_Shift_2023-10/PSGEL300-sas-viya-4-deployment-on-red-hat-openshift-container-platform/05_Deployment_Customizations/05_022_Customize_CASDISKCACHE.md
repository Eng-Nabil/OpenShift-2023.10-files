![Global Enablement & Learning](https://gelgitlab.race.sas.com/GEL/utilities/writing-content-in-markdown/-/raw/master/img/gel_banner_logo_tech-partners.jpg)

# Customize CAS DISK CACHE

In this exercise we will walk through the steps required to configure CAS so that it locates the CAS working directory (CAS DISK CACHE) in alternative locations.

* [Prepare the SAS environment](#prepare-the-sas-environment)
* [Verify the current status](#verify-the-current-status)
* [Configure CAS\_DISK\_CACHE](#configure-cas_disk_cache)
* [Verify the new setting](#verify-the-new-setting)
* [Next Steps](#next-steps)
* [Complete Hands-on Navigation Index](#complete-hands-on-navigation-index)

## Prepare the SAS environment

1. For this exercise, we'll create a new folder to store our customization yaml files. We will copy the existing customizations already created under `/home/cloud-user/project/gelocp`, then add new configuration files.

1. Create the new configuration folder and copy the existing deployment directory into it:

    ```bash
    cp -rp ~/project/gelocp ~/project/gelocp-custom
    ```

1. Save the existing site.yaml file:

    ```bash
    mv ~/project/gelocp-custom/site.yaml ~/project/gelocp-custom/site.yaml.orig
    ```

## Verify the current status

By default, CAS servers are configured to use a directory that is named `/cas/cache` on each controller and worker pod. This directory is provisioned as a Kubernetes emptyDir and uses disk space from the root volume of the Kubernetes node.

The default configuration is acceptable for testing and evaluation, but not for production workloads. If disk space in the root volume of the node becomes low, then Kubernetes begins evicting pods.

1. Use the following command to fetch the ```sasadm``` user's password:

    ```sh
    echo "sasadm's password is: $(cat /home/cloud-user/azureADusers.txt|grep 'sasadm'|awk -F'::' '{print $2}')"
    ```

    You should see something like the following:

    ```log
    sasadm's password is: ############
    ```

1. Logon to SAS Studio with the `sasadm` user (SAS administrator) and the password obtained above. You should find a bookmark to SAS Studio in the Chrome bookmarks on the Windows client, or you can query the URL from OpenShift with the following command:

    ```sh
    echo "https://$(oc -n gel-viya get route sas-studio-app -o jsonpath="{.spec.host}")/SASStudio"
    ```

    You may have to accept Chrome security warning a couple of times.

    When asked, assume the admin role.

1. Submit the following code:

    ```sas
    cas sess1;

    proc cas;
        session sess1;
        accessControl.assumeRole / adminRole="superuser";
        builtins.getCacheInfo result=results;
        print results.diskCacheInfo;
    run;
    quit;

    cas sess1 clear;
    ```

    You should get a result similar to the following:

    ![](img/SASStudio_CASDISKCACHE_default.png)

    What can we understand from these results?

    * The CAS disk cache is located at the path /cas/cache. This is the path as seen by the CAS process inside the pods.
    * On all nodes (controller, workers), that path resides on a disk with ~127GB of capacity, on a device called `sda4` or `sdb4`.
    * From the previous exercise, we can recognize that these correspond to the OS root disks.
    * This result indirectly confirms that we are using a default emptyDir.

## Configure CAS_DISK_CACHE

We will follow and adapt the instructions from the [official documentation](https://go.documentation.sas.com/doc/en/sasadmincdc/v_035/dplyml0phy0dkr/n08u2yg8tdkb4jn18u8zsi6yfv3d.htm#p0wtwirnp4uayln19psyon1rkkr9) to configure CAS so that the CAS Disk Cache will use the local temporary storage we configured in the previous exercise.

1. Use the following commands to create a file named `cas_disk_cache-config.yaml` in the `~/project/gelocp-custom/site-config/` directory:

    ```bash
    cat > ~/project/gelocp-custom/site-config/cas_disk_cache-config.yaml <<-EOF
    # # this defines the volume and volumemount for CAS DISK CACHE location
    ---
    apiVersion: builtin
    kind: PatchTransformer
    metadata:
      name: cas-cache-hostpath
    patch: |-
      - op: add
        path: /spec/controllerTemplate/spec/volumes/-
        value:
          name: cas-cache-sastmp
          ephemeral:
            volumeClaimTemplate:
              spec:
                accessModes: [ "ReadWriteOnce" ]
                storageClassName: "sastmp"
                resources:
                  requests:
                    storage: 100Gi
      - op: add
        path: /spec/controllerTemplate/spec/containers/0/volumeMounts/-
        value:
          name: cas-cache-sastmp
          mountPath: /cas/cache-sastmp # # mountPath is the path inside the pod that CAS will reference
      - op: add
        path: /spec/controllerTemplate/spec/containers/0/env/-
        value:
          name: CASENV_CAS_DISK_CACHE
          value: "/cas/cache-sastmp" # # This has to match the value that is inside the pod
    target:
      version: v1alpha1
      group: viya.sas.com
      kind: CASDeployment
      # # Target filtering: chose/uncomment one of these option:
      # #    To target only the default CAS server (cas-shared-default) :
      labelSelector: "sas.com/cas-server-default"
      # #    To target only a single CAS server (e.g. MyCAS) other than default:
      # name: {{MyCAS}}
      # #    To target all CAS Servers
      # name: .*
    EOF
    ```

    If you compare this file to the example in the documentation, you can notice how we specified the "ephemeral" volume template with all its properties, instead of the "hostPath" used by the online example.

1. Use the following command to update the kustomization.yaml to include our new file::

    ```bash
    sed -i '/cas_disk_cache-config.yaml/d' ~/project/gelocp-custom/kustomization.yaml; \
    sed -i '/.*update-fsgroup.yaml/a\ \ -\ site-config/cas_disk_cache-config.yaml' ~/project/gelocp-custom/kustomization.yaml
    ```

1. Check the modified `kustomization.yaml` :

    ```sh
    diff ~/project/gelocp/kustomization.yaml ~/project/gelocp-custom/kustomization.yaml
    ```

    You get an output similar to the following:

    ```log
    28a29
    >   - site-config/cas_disk_cache-config.yaml
    ```

1. Use the following commands to rebuild the site.yaml:

    ```bash
    cd ~/project/gelocp-custom/
    kustomize build -o site.yaml
    ```

1. Check the modified `kustomization.yaml` :

    ```sh
    diff ~/project/gelocp/site.yaml ~/project/gelocp-custom/site.yaml
    ```

    You get an output similar to the following:

    ```diff
    76807a76808,76809
    >         - name: CASENV_CAS_DISK_CACHE
    >           value: /cas/cache-sastmp
    76882a76885,76886
    >         - mountPath: /cas/cache-sastmp
    >           name: cas-cache-sastmp
    77204a77209,77218
    >       - ephemeral:
    >           volumeClaimTemplate:
    >             spec:
    >               accessModes:
    >               - ReadWriteOnce
    >               resources:
    >                 requests:
    >                   storage: 100Gi
    >               storageClassName: sastmp
    >         name: cas-cache-sastmp
    ```

1. Use the following commands to rebuild the site.yaml:

    ```bash
    oc apply -n gel-viya --selector="sas.com/admin=namespace" -f site.yaml --prune
    ```

1. Until the existing CAS server are restarted, the deployment will continue to run the previous version without the modified CAS Disk Cache location. Run the following command to delete the CAS server pods, so that the CAS Operator will automatically restart them:

    ```bash
    oc -n gel-viya delete pods -l app.kubernetes.io/managed-by=sas-cas-operator
    ```

    You should get a confirmation similar to the following:

    ```log
    pod "sas-cas-server-default-controller" deleted
    pod "sas-cas-server-default-worker-0" deleted
    pod "sas-cas-server-default-worker-1" deleted
    ```

1. Wait a few seconds, then submit the following command to verify the status of the CAS pods:

    ```sh
    oc -n gel-viya get pods -l app.kubernetes.io/managed-by=sas-cas-operator
    ```

    You should get a "No resources found in gel-viya namespace." message. That's not what we expected: the CAS Operator should have restarted the CAS server and the previous command should show the 3 CAS pods running. Lets' dig into the CAS Operator logs to see what's happening.

1. Submit the following command to look for the last occurrence of the string "ephemeral" in the CAS operator log:

    ```sh
    oc logs -l app=sas-cas-operator --tail=-1 | grep ephemeral | tail -1 | jq
    ```

    You should get a listing similar to the following:

    ```json
    {
      "level": "error",
      "ts": 1674678823.686096,
      "logger": "controller.casdeployment",
      "msg": "Reconciler error",
      "reconciler group": "viya.sas.com",
      "reconciler kind": "CASDeployment",
      "name": "default",
      "namespace": "gel-viya",
      "error": "pods \"sas-cas-server-default-controller\" is forbidden: unable to validate against any security context constraint: [provider \"anyuid\": Forbidden: not usable by user or serviceaccount, provider \"sas-watchdog\": Forbidden: not usable by user or serviceaccount, provider restricted: .spec.securityContext.fsGroup: Invalid value: []int64{1001}: 1001 is not an allowed group, spec.volumes[16]: Invalid value: \"ephemeral\": ephemeral volumes are not allowed to be used, spec.initContainers[0].securityContext.runAsUser: Invalid value: 1001: must be in the ranges: [1000660000, 1000669999], spec.initContainers[1].securityContext.runAsUser: Invalid value: 1001: must be in the ranges: [1000660000, 1000669999], spec.containers[0].securityContext.runAsUser: Invalid value: 1001: must be in the ranges: [1000660000, 1000669999], spec.containers[1].securityContext.runAsUser: Invalid value: 1001: must be in the ranges: [1000660000, 1000669999], spec.containers[2].securityContext.runAsUser: Invalid value: 1001: must be in the ranges: [1000660000, 1000669999], provider \"nonroot\": Forbidden: not usable by user or serviceaccount, provider \"sas-microanalytic-score\": Forbidden: not usable by user or serviceaccount, provider \"pgo\": Forbidden: not usable by user or serviceaccount, provider \"pgo-backrest\": Forbidden: not usable by user or serviceaccount, provider \"hostmount-anyuid\": Forbidden: not usable by user or serviceaccount, provider \"machine-api-termination-handler\": Forbidden: not usable by user or serviceaccount, provider \"hostnetwork\": Forbidden: not usable by user or serviceaccount, provider \"hostaccess\": Forbidden: not usable by user or serviceaccount, provider \"sas-opendistro\": Forbidden: not usable by user or serviceaccount, provider \"node-exporter\": Forbidden: not usable by user or serviceaccount, provider \"privileged\": Forbidden: not usable by user or serviceaccount]",
      "stacktrace": "sigs.k8s.io/controller-runtime/pkg/internal/controller.(*Controller).processNextWorkItem\n\t/go/pkg/mod/sigs.k8s.io/controller-runtime@v0.11.2/pkg/internal/controller/controller.go:266\nsigs.k8s.io/controller-runtime/pkg/internal/controller.(*Controller).Start.func2.2\n\t/go/pkg/mod/sigs.k8s.io/controller-runtime@v0.11.2/pkg/internal/controller/controller.go:227"
    }
    ```

1. We have to interpret the **error** field to track down what is the issue.

    * We can see that OpenShift is unable to start the **sas-cas-server-default-controller** pod after failing to find a suitable security context constraint for it.
    * If you remember the exercise [04_023 Prepare for OpenShift](/04_Deployment/04_023_Prepare_for_OpenShift.md), we created a custom scc called `cas-server-scc` and then assigned it to the `sas-cas-server` service account, so CAS should be able to use that.
    * From the error we can understand that it is instead trying all the existing security context constraints, one after the other, and failing with all.
    * This is an indirect confirmation that something is wrong with the `cas-server-scc` scc. Since CAS was working correctly until our latest change, we suspect it has to do with the new setting to use ephemeral volumes.
    * The error reported with the `restricted` scc (which should be usable by all service accounts) seems to confirm our suspicion: "*spec.volumes[16]: Invalid value: \"ephemeral\": ephemeral volumes are not allowed to be used*"
    * The documentation page [Preparing for OpenShift](https://go.documentation.sas.com/doc/en/sasadmincdc/v_036/dplyml0phy0dkr/p1h8it1wdu2iaxn1bkd8anfcuxny.htm) contains instructions for additional steps required to enable hostPath mounts for CAS. A close read of that sections reveals that similar additional steps could be required for ephemeral mounts.

1. Check the current list of volume types permitted by the `cas-server-scc` scc with the following command:

    ```bash
    oc get scc sas-cas-server -o jsonpath='{.volumes}'
    ```

    You should get a listing similar to the following, which shows that "ephemeral" is not there:

    ```log
    ["configMap","downwardAPI","emptyDir","nfs","persistentVolumeClaim","projected","secret"]
    ```

1. Add the "ephemeral" volume type to the scc with the following command, and verify the result:

    ```bash
    oc -n gel-viya get scc sas-cas-server -o json | jq '.volumes += ["ephemeral"]' | oc -n gel-viya apply -f -
    oc get scc sas-cas-server -o jsonpath='{.volumes}'
    ```

    Expected result:

    ```log
    securitycontextconstraints.security.openshift.io/sas-cas-server configured
    ["configMap","downwardAPI","emptyDir","ephemeral","nfs","persistentVolumeClaim","projected","secret"]
    ```

1. Nothing else should be required. The CAS operator should now be able to start the CAS pods. This may take a couple of minutes; let's check that they are running:

    ```bash
    # wait 30 seconds
    sleep 30
    oc -n gel-viya get pods -l app.kubernetes.io/managed-by=sas-cas-operator
    ```

    You should get a listing such as the following:

    ```log
    NAME                                READY   STATUS            RESTARTS   AGE
    sas-cas-server-default-controller   1/3     Running           0          27s
    sas-cas-server-default-worker-0     0/3     PodInitializing   0          24s
    sas-cas-server-default-worker-1     0/3     PodInitializing   0          24s
    ```

1. Wait up to 5 minutes until all CAS pods are fully running:

    ```bash
    kubectl wait --for=condition=Ready  --timeout=300s pod  -l app.kubernetes.io/managed-by=sas-cas-operator
    ```

    Expected output:

    ```log
    pod/sas-cas-server-default-controller condition met
    pod/sas-cas-server-default-worker-0 condition met
    pod/sas-cas-server-default-worker-1 condition met
    ```

## Verify the new setting

Let's go back to SAS Studio and run the same code as before to check the new setting.

1. Use the following command to fetch the ```sasadm``` user's password:

    ```sh
    echo "sasadm's password is: $(cat /home/cloud-user/azureADusers.txt|grep 'sasadm'|awk -F'::' '{print $2}')"
    ```

    You should see something like the following:

    ```log
    sasadm's password is: ############
    ```

1. Logon to SAS Studio with the `sasadm` user (SAS administrator) and the password obtained above. You should find a bookmark to SAS Studio in the Chrome bookmarks on the Windows client, or you can query the URL from OpenShift with the following command:

    ```sh
    echo "https://$(oc -n gel-viya get route sas-studio-app -o jsonpath="{.spec.host}")/SASStudio"
    ```

    You may have to accept Chrome security warning a couple of times.

    When asked, assume the admin role.

1. Submit the following code:

    ```sas
    cas sess1;

    proc cas;
        session sess1;
        accessControl.assumeRole / adminRole="superuser";
        builtins.getCacheInfo result=results;
        print results.diskCacheInfo;
    run;
    quit;

    cas sess1 clear;
    ```

    You should get a result similar to the following:

    ![](img/SASStudio_CASDISKCACHE_ephemeral.png)

    Notice how:

    * The CAS disk cache is now located at the new path /cas/cache-sastmp, as we specified. This is the path as seen by the CAS process inside the pods.
    * On all nodes (controller, workers), that path resides on a disk with ~299GB of capacity, on a different device then the previous run.
    * From the previous exercise, we can recognize that these correspond to the Azure temporary SDD disks.
    * SUCCESS!

---

## Next Steps

For now, this is the end of the workshop. Feel free to experiment using the SAS Viya environment you just installed.

Before leaving, remember to [cleanup](/09_The_End/09_999_Cleanup.md)!

---

##  Complete Hands-on Navigation Index
<!-- startnav -->
* [01 Workshop Introduction / 01 031 Access the Environment](/01_Workshop_Introduction/01_031_Access_the_Environment.md)
* [01 Workshop Introduction / 01 032 Verify the Environment](/01_Workshop_Introduction/01_032_Verify_the_Environment.md)
* [01 Workshop Introduction / 01 999 Fast track with cheatcodes](/01_Workshop_Introduction/01_999_Fast_track_with_cheatcodes.md)
* [02 OpenShift Introduction / 02 051 Explore OpenShift](/02_OpenShift_Introduction/02_051_Explore_OpenShift.md)
* [04 Deployment / 04 071 Perform the Prerequisites](/04_Deployment/04_071_Perform_the_Prerequisites.md)
* [04 Deployment / 04 072 Prepare for Viya Deployment](/04_Deployment/04_072_Prepare_for_Viya_Deployment.md)
* [04 Deployment / 04 073 Prepare for OpenShift](/04_Deployment/04_073_Prepare_for_OpenShift.md)
* [04 Deployment / 04 074 Customize Viya Deployment](/04_Deployment/04_074_Customize_Viya_Deployment.md)
* [04 Deployment / 04 075 Manually Deploy Viya](/04_Deployment/04_075_Manually_Deploy_Viya.md)
* [05 Deployment Customizations / 05 021 Provision Temp Storage](/05_Deployment_Customizations/05_021_Provision_Temp_Storage.md)
* [05 Deployment Customizations / 05 022 Customize CASDISKCACHE](/05_Deployment_Customizations/05_022_Customize_CASDISKCACHE.md)**<-- you are here**
* [09 The End / 09 999 Cleanup](/09_The_End/09_999_Cleanup.md)
<!-- endnav -->
