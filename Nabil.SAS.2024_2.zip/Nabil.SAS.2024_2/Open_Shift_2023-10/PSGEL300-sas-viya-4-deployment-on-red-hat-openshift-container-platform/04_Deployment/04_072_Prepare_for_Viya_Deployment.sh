oc new-project gel-viya
oc create rolebinding \
    sas-viya-admin \
    --clusterrole=admin \
    --namespace=gel-viya \
    --user="gatedemo004"
cat > /home/cloud-user/project/clusterrole-sas-admin.yaml << EOF
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: sas-admin-role
rules:
- apiGroups: ["opendistro.sas.com"]
  resources: ["*"]
  verbs: ["*"]
- apiGroups: ["postgres-operator.crunchydata.com"]
  resources: ["*"]
  verbs: ["*"]
- apiGroups: ["redis.kun"]
  resources: ["*"]
  verbs: ["*"]
- apiGroups: ["viya.sas.com"]
  resources: ["*"]
  verbs: ["*"]
- apiGroups: ["webinfdsvr.sas.com"]
  resources: ["*"]
  verbs: ["*"]
- apiGroups: ["iot.sas.com"]
  resources: ["*"]
  verbs: ["*"]
- apiGroups: [""]
  resources: ["podtemplates"]
  verbs: ["get", "list", "watch", "create", "update", "patch", "delete"]
EOF

oc apply -f /home/cloud-user/project/clusterrole-sas-admin.yaml
oc create rolebinding \
    sas-viya-sas-admin \
    --clusterrole=sas-admin-role \
    --namespace=gel-viya \
    --user="gatedemo004"
cd ~/project
#load parameters from file
source <( cat /opt/gellow_work/vars/vars.txt )

echo "SAS Viya cadence and version = ${GELLOW_CADENCE_NAME}-${GELLOW_CADENCE_VERSION}"

bash /opt/gellow_code/scripts/common/generate_sas_bases.sh \
      --cadence-name ${GELLOW_CADENCE_NAME} \
      --cadence-version ${GELLOW_CADENCE_VERSION} \
      --order-nickname ${GELLOW_ORDERNICKNAME} \
      --output-folder ~/project/gelocp
mkdir -p ~/project/gelocp/site-config/
mkdir -p ~/project/gelocp/site-config/security/
mkdir -p ~/project/gelocp/site-config/configure-postgres/internal/pgo-client
