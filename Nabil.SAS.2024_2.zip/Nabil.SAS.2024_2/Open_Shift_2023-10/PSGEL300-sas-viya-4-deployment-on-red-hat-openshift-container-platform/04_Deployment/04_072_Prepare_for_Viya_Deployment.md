![Global Enablement & Learning](https://gelgitlab.race.sas.com/GEL/utilities/writing-content-in-markdown/-/raw/master/img/gel_banner_logo_tech-partners.jpg)

# Prepare for SAS Viya Deployment

* [Steps for the Cluster Administrator](#steps-for-the-cluster-administrator)
    * [Create the SAS Viya namespace](#create-the-sas-viya-namespace)
    * [Grant Namespace Admin Rights to the SAS Administrator](#grant-namespace-admin-rights-to-the-sas-administrator)
* [Steps for the SAS Deployment Engineer](#steps-for-the-sas-deployment-engineer)
    * [Prepare the Order Deployment Assets](#prepare-the-order-deployment-assets)
    * [Create a site-config directory](#create-a-site-config-directory)
* [Next Steps](#next-steps)
* [Complete Hands-on Navigation Index](#complete-hands-on-navigation-index)

In this workshop, we want to operate in a way that is close to customer environments. For this reason, we separate the steps that require full cluster administration rights, which will be performed by an OpenShift administrator, from the steps that require more limited privileges, performed by the SAS Deployment Engineer or SAS Administrator.

## Steps for the Cluster Administrator

### Create the SAS Viya namespace

1. Run this command to create the "gel-viya" namespace in the cluster. This is possible because we logged into the OCP cluster as a user with full cluster-admin rights (`gatedemo003`).

    ```bash
    oc new-project gel-viya
    ```

### Grant Namespace Admin Rights to the SAS Administrator
Create a dedicated administrator with full permissions on the gel-viya namespace, but limited access to the cluster.

1. Submit the following code to grant namespace administrative capabilities to the `gatedemo004` user

    ```bash
    oc create rolebinding \
        sas-viya-admin \
        --clusterrole=admin \
        --namespace=gel-viya \
        --user="gatedemo004"
    ```

1. Create a custom ClusterRole to grant read access to specific resources required to deploy SAS Viya

    ```bash
    cat > /home/cloud-user/project/clusterrole-sas-admin.yaml << EOF
    apiVersion: rbac.authorization.k8s.io/v1
    kind: ClusterRole
    metadata:
      name: sas-admin-role
    rules:
    - apiGroups: ["opendistro.sas.com"]
      resources: ["*"]
      verbs: ["*"]
    - apiGroups: ["postgres-operator.crunchydata.com"]
      resources: ["*"]
      verbs: ["*"]
    - apiGroups: ["redis.kun"]
      resources: ["*"]
      verbs: ["*"]
    - apiGroups: ["viya.sas.com"]
      resources: ["*"]
      verbs: ["*"]
    - apiGroups: ["webinfdsvr.sas.com"]
      resources: ["*"]
      verbs: ["*"]
    - apiGroups: ["iot.sas.com"]
      resources: ["*"]
      verbs: ["*"]
    - apiGroups: [""]
      resources: ["podtemplates"]
      verbs: ["get", "list", "watch", "create", "update", "patch", "delete"]
    EOF

    oc apply -f /home/cloud-user/project/clusterrole-sas-admin.yaml
    ```

1. Grant the custom `sas-admin-role` to the `gatedemo004` user

    ```bash
    oc create rolebinding \
        sas-viya-sas-admin \
        --clusterrole=sas-admin-role \
        --namespace=gel-viya \
        --user="gatedemo004"
    ```

1. Verify user permissions.

    ```sh
    # gatedemo004 does not have access to cluster-scoped artifacts:
    kubectl auth can-i create projects --as gatedemo004
    kubectl auth can-i create crd --as gatedemo004
    # gatedemo003 instead has access to cluster-scoped artifacts:
    kubectl auth can-i create projects --as gatedemo003
    kubectl auth can-i create crd --as gatedemo003
    # gatedemo004 only has access to the gel-viya namespace:
    kubectl auth can-i create pods --namespace default --as gatedemo004
    kubectl auth can-i create pods --namespace gel-viya --as gatedemo004
    ```

    You should see output similar to the following:

    ```log
    $ # gatedemo004 does not have access to cluster-scoped artifacts:
    $ kubectl auth can-i create projects --as gatedemo004
    Warning: resource 'projects' is not namespace scoped in group 'project.openshift.io'
    no
    $ kubectl auth can-i create crd --as gatedemo004
    Warning: resource 'customresourcedefinitions' is not namespace scoped in group 'apiextensions.k8s.io'
    no
    $ # gatedemo003 instead has access to cluster-scoped artifacts:
    $ kubectl auth can-i create projects --as gatedemo003
    Warning: resource 'projects' is not namespace scoped in group 'project.openshift.io'
    yes
    $ kubectl auth can-i create crd --as gatedemo003
    Warning: resource 'customresourcedefinitions' is not namespace scoped in group 'apiextensions.k8s.io'
    yes
    $ # gatedemo004 only has access to the gel-viya namespace:
    $ kubectl auth can-i create pods --namespace default --as gatedemo004
    no
    $ kubectl auth can-i create pods --namespace gel-viya --as gatedemo004
    yes
    ```

    As you can read from the output, `gatedemo004` cannot create artifacts outside the gel-viya namespace, while it has that capability in the gel-viya namespace. `gatedemo003`, the cluster administrator, does not have these limitations.

## Steps for the SAS Deployment Engineer

### Prepare the Order Deployment Assets

The first step to deploy SAS Viya is to retrieve the deployment assets. In a normal scenario, you would:

* log in to the <https://my.sas.com/> portal and
* download a .tgz file containing your assets
* explode the .tgz into `~/project/gelocp/` (our project directory)
* which would create `~/project/gelocp/sas-bases`

Instead, in order to keep the materials in this course up to date, we will use a script to generate the assets for you.

1. Run the following commands (copy-paste all lines together)

    ```bash
    cd ~/project
    #load parameters from file
    source <( cat /opt/gellow_work/vars/vars.txt )

    echo "SAS Viya cadence and version = ${GELLOW_CADENCE_NAME}-${GELLOW_CADENCE_VERSION}"

    bash /opt/gellow_code/scripts/common/generate_sas_bases.sh \
          --cadence-name ${GELLOW_CADENCE_NAME} \
          --cadence-version ${GELLOW_CADENCE_VERSION} \
          --order-nickname ${GELLOW_ORDERNICKNAME} \
          --output-folder ~/project/gelocp
    ```

### Create a site-config directory

Create a "site-config" directory to store our specific configuration (it is a separated space from the software-provided manifests).

1. Run the following commands

    ```bash
    mkdir -p ~/project/gelocp/site-config/
    mkdir -p ~/project/gelocp/site-config/security/
    mkdir -p ~/project/gelocp/site-config/configure-postgres/internal/pgo-client
    ```
---

## Next Steps

Deployment steps for OpenShift are different from those required for other infrastructures.

Click [here](/04_Deployment/04_073_Prepare_for_OpenShift.md) to move onto the next exercise that describes those differences: ***04 073 Prepare for OpenShift***

---

## Complete Hands-on Navigation Index
<!-- startnav -->
* [01 Workshop Introduction / 01 031 Access the Environment](/01_Workshop_Introduction/01_031_Access_the_Environment.md)
* [01 Workshop Introduction / 01 032 Verify the Environment](/01_Workshop_Introduction/01_032_Verify_the_Environment.md)
* [01 Workshop Introduction / 01 999 Fast track with cheatcodes](/01_Workshop_Introduction/01_999_Fast_track_with_cheatcodes.md)
* [02 OpenShift Introduction / 02 051 Explore OpenShift](/02_OpenShift_Introduction/02_051_Explore_OpenShift.md)
* [04 Deployment / 04 071 Perform the Prerequisites](/04_Deployment/04_071_Perform_the_Prerequisites.md)
* [04 Deployment / 04 072 Prepare for Viya Deployment](/04_Deployment/04_072_Prepare_for_Viya_Deployment.md)**<-- you are here**
* [04 Deployment / 04 073 Prepare for OpenShift](/04_Deployment/04_073_Prepare_for_OpenShift.md)
* [04 Deployment / 04 074 Customize Viya Deployment](/04_Deployment/04_074_Customize_Viya_Deployment.md)
* [04 Deployment / 04 075 Manually Deploy Viya](/04_Deployment/04_075_Manually_Deploy_Viya.md)
* [05 Deployment Customizations / 05 021 Provision Temp Storage](/05_Deployment_Customizations/05_021_Provision_Temp_Storage.md)
* [05 Deployment Customizations / 05 022 Customize CASDISKCACHE](/05_Deployment_Customizations/05_022_Customize_CASDISKCACHE.md)
* [09 The End / 09 999 Cleanup](/09_The_End/09_999_Cleanup.md)
<!-- endnav -->
