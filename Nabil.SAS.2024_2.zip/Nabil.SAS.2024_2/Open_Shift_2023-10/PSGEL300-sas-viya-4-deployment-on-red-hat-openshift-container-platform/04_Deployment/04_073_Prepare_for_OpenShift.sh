# check the current labels and taints:
kubectl get nodes -o=custom-columns=NAME:.metadata.name,LABELS:.metadata.labels
kubectl get nodes -o=custom-columns=NAME:.metadata.name,TAINTS:.spec.taints
kubectl label nodes $(kubectl get nodes | grep worker-[1,2] | awk '{print $1}' | tr '\n' ' ') workload.sas.com/class=compute
cd ~/project/gelocp
find ./sas-bases -name "*scc*.yaml"
yq4 eval '
    .allowPrivilegeEscalation = true,
    .allowPrivilegedContainer = true,
    .runAsUser.type = "RunAsAny"' \
    ./sas-bases/examples/configure-elasticsearch/internal/openshift/sas-opendistro-scc.yaml > ./site-config/sas-opendistro-scc.yaml
# verify we are logged in as the gatedemo003 cluster administrator
oc whoami
# CAS: pick only one of cas-server-scc.yaml or cas-server-scc-host-launch.yaml
oc apply -f ./sas-bases/examples/cas/configure/cas-server-scc.yaml
# SPRE
oc apply -f ./sas-bases/examples/sas-programming-environment/watchdog/sas-watchdog-scc.yaml
# MAS
oc apply -f ./sas-bases/overlays/sas-microanalytic-score/service-account/sas-microanalytic-score-scc.yaml
# Model Repository Service
oc apply -f ./sas-bases/overlays/sas-model-repository/service-account/sas-model-repository-scc.yaml
# OpenSearch
oc apply -f ./site-config/sas-opendistro-scc.yaml
cd ~/project/gelocp/
NS="gel-viya"
oc -n ${NS} adm policy add-scc-to-user sas-cas-server -z sas-cas-server
oc -n ${NS} adm policy add-scc-to-user sas-opendistro -z sas-opendistro
oc -n ${NS} adm policy add-scc-to-user sas-microanalytic-score -z sas-microanalytic-score
oc -n ${NS} adm policy add-scc-to-user sas-model-repository -z sas-model-repository
oc -n ${NS} adm policy add-scc-to-user sas-watchdog -z sas-programming-environment
oc -n ${NS} adm policy add-scc-to-user hostmount-anyuid -z sas-programming-environment
cd ~/project/gelocp/
NS="gel-viya"
# get the ID from OpenShift
NS_GROUP_ID=$(oc get project ${NS} -o jsonpath='{.metadata.annotations.openshift\.io/sa\.scc\.supplemental-groups}' | cut -f1 -d / )
echo "The supplemental group ID for the ${NS} namespace is: ${NS_GROUP_ID}"
sed -e "s|{{ FSGROUP_VALUE }}|${NS_GROUP_ID}|g" \
    ./sas-bases/examples/security/container-security/update-fsgroup.yaml > ./site-config/security/update-fsgroup.yaml
