# Copy the site-default
cp /opt/gellow_code/scripts/loop/gelenable/gelenable_site-config/gelenable-sitedefault.yaml \
   ~/project/gelocp/site-config/
# Set the desired number of workers
CAS_WORKERS=2
# Copy the sample PatchTransformer and configure the desired number of workers
sed -e "s/{{ NUMBER-OF-WORKERS }}/${CAS_WORKERS}/g" \
    ~/project/gelocp/sas-bases/examples/cas/configure/cas-manage-workers.yaml \
    > ~/project/gelocp/site-config/cas-manage-workers.yaml
# Set the required number of workers
# In this workshop we keep the numbers low on purpose to be able to use smaller machines
CAS_CPU_=1
CAS_MEMORY=2Gi
# Copy the sample PatchTransformer and configure the desired number of workers
sed -e "s/{{ AMOUNT-OF-RAM }}/${CAS_MEMORY}/g" \
    -e "s/{{ NUMBER-OF-CORES }}/${CAS_CPU_}/g" \
    ~/project/gelocp/sas-bases/examples/cas/configure/cas-manage-cpu-and-memory.yaml \
    > ~/project/gelocp/site-config/cas-manage-cpu-and-memory.yaml
# Copy the file used to generate the ingress certificate
cp ~/project/gelocp/sas-bases/examples/security/openssl-generated-ingress-certificate.yaml \
   ~/project/gelocp/site-config/security/openssl-generated-ingress-certificate.yaml
cat > ~/project/gelocp/site-config/storageclass.yaml <<-EOF
kind: RWXStorageClass
metadata:
  name: wildcard
spec:
  storageClassName: sas-azurefile
EOF
### Set the FQDN of the ingress
NS="gel-viya"
# get the base domain from OpenShift ingress
APPS_DOMAIN=$(oc get ingresscontroller.operator.openshift.io -n openshift-ingress-operator -o jsonpath='{.items[].status.domain}')
INGRESS_FQDN="${NS}.${APPS_DOMAIN}"
echo "SAS Viya Namespace: ${NS}"
echo "SAS Viya Ingress: ${INGRESS_FQDN}"

cat > ~/project/gelocp/kustomization.yaml <<-EOF
---
namespace: ${NS}
resources:
  - sas-bases/base
  - sas-bases/overlays/network/route.openshift.io/v1/route                           ## OCP: route instead of ingress
  - sas-bases/overlays/cas-server
  - sas-bases/overlays/crunchydata/postgres-operator
  - sas-bases/overlays/postgres/platform-postgres
  - sas-bases/overlays/internal-elasticsearch
  - sas-bases/overlays/update-checker
#  - sas-bases/overlays/cas-server/auto-resources                                    ## no CAS auto-resources, since no node has been labeled for CAS
  - site-config/security/openssl-generated-ingress-certificate.yaml                  ## causes openssl to generate an ingress certificate and key and store them in a secret
  - sas-bases/overlays/sas-workload-orchestrator

configurations:
  - sas-bases/overlays/required/kustomizeconfig.yaml

transformers:
  - sas-bases/overlays/internal-elasticsearch/sysctl-transformer.yaml
  - sas-bases/overlays/required/transformers.yaml
#  - sas-bases/overlays/cas-server/auto-resources/remove-resources.yaml              ## no CAS auto-resources, since no node has been labeled for CAS
  - sas-bases/overlays/internal-elasticsearch/internal-elasticsearch-transformer.yaml
  # custom settings
  - site-config/cas-manage-workers.yaml
  - site-config/cas-manage-cpu-and-memory.yaml
  # OCP security settings
  - sas-bases/overlays/security/container-security/remove-seccomp-transformer.yaml   ## OCP: remove seccomp
  - site-config/security/update-fsgroup.yaml                                         ## OCP: use an fsGroup permitted by OCP restricted SCC

components:
  - sas-bases/components/crunchydata/internal-platform-postgres
  - sas-bases/components/security/core/base/full-stack-tls
  - sas-bases/components/security/network/route.openshift.io/route/full-stack-tls    ## OCP: route instead of ingress

patches:
- path: site-config/storageclass.yaml
  target:
    kind: PersistentVolumeClaim
    annotationSelector: sas.com/component-name in (sas-backup-job,sas-data-quality-services,sas-commonfiles,sas-cas-operator,sas-pyconfig,sas-event-stream-processing-studio-app,sas-reference-data-deploy-utilities,sas-model-publish)

configMapGenerator:
  - name: ingress-input
    behavior: merge
    literals:
      - INGRESS_HOST=${INGRESS_FQDN}

  - name: sas-shared-config
    behavior: merge
    literals:
      - SAS_SERVICES_URL=https://${INGRESS_FQDN}

secretGenerator:
  - name: sas-consul-config
    behavior: merge
    files:
      - SITEDEFAULT_CONF=site-config/gelenable-sitedefault.yaml
EOF
