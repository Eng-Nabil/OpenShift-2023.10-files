oc version
# Get the StorageClass information
oc get sc
oc -n openshift-ingress get service router-default
oc new-project cert-utils-operator
oc apply -f https://raw.githubusercontent.com/redhat-cop/cert-utils-operator/master/config/operatorhub/operator.yaml -n cert-utils-operator
## wait until pods start
sleep 30
oc -n cert-utils-operator wait --for=condition=ready pod -l=control-plane=cert-utils-operator --timeout=300s
