## IMPORTANT KEEP THIS FILE IN THIS FORMAT!
### gellow_webhook must be the webhook you create for your project
### gellow_send_final_notification ALL|FAIL|OFF

### Start environment variable definitions name-value pairs on next line each on its own line

gellow_webhook="https://sasoffice365.webhook.office.com/webhookb2/e501090a-af3d-426c-bf35-2374d5e7d211@b1c14d5c-3625-45b3-a430-9552373a0c2f/IncomingWebhook/5014b1966b414f54b05f719bda30d4cf/6263caa5-dd02-4db8-a259-e9673cbdd9c4"

gellow_send_final_notification="ALL"
