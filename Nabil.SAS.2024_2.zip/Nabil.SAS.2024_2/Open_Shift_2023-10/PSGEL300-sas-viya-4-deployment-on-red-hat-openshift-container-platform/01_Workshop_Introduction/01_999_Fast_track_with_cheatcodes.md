![Global Enablement & Learning](https://gelgitlab.race.sas.com/GEL/utilities/writing-content-in-markdown/-/raw/master/img/gel_banner_logo_tech-partners.jpg)

# Fast track with the cheatcodes

* [WARNING](#warning)
* [IDEMPOTENCY](#idempotency)
* [(Re)generate the cheatcodes](#regenerate-the-cheatcodes)
* [Run the cheatcodes](#run-the-cheatcodes)
* [Navigation](#navigation)

## WARNING

The 'cheatcodes' have been developed for this workshop and are **NOT** part of the SAS Viya software, nor are they an official tool supported by SAS. They provide an automated path through the lab exercises.

## IDEMPOTENCY

* The cheatcodes are designed to be idempotent, you should be able to run them as many time as required.

## (Re)generate the cheatcodes

* The cheatcodes are automatically built from md files that are provided in the "PSGEL300-sas-viya-4-deployment-on-red-hat-openshift-container-platform" folder.

* Run these commands to re-generate the cheatcodes for the OCP Hands-on, using the GELLOW cheatcode generator.

    ```sh
    cd ~/PSGEL300-sas-viya-4-deployment-on-red-hat-openshift-container-platform/
    git pull
    # optionally, you can switch to a different version branch
    # ex:
    # git checkout "release/stable-2021.1.6"
    /opt/gellow_code/scripts/cheatcodes/create.cheatcodes.sh /home/cloud-user/PSGEL300-sas-viya-4-deployment-on-red-hat-openshift-container-platform/
    ```

  Now you can directly call the cheatcodes for each step.

## Run the cheatcodes

* The following command will automatically run all the exercises of the workshop for you: verify the OCP cluster, perform the pre-requisites, deploy Viya 4, and perform post-deployment configurations.

    ```sh
    bash -x ~/PSGEL300*/_all.sh
    ```

* To automatically run only a specific exercise, print the content of the `_all.sh` file and copy-paste the command you want to run:

    ```sh
    cat ~/PSGEL300*/_all.sh
    # run the exercise "01_Workshop_Introduction/01_032_Verify_the_Environment":
    bash -x /home/cloud-user/PSGEL300-sas-viya-4-deployment-on-red-hat-openshift-container-platform/01_Workshop_Introduction/01_032_Verify_the_Environment.sh 2>&1 | tee -a  /home/cloud-user/PSGEL300-sas-viya-4-deployment-on-red-hat-openshift-container-platform/01_Workshop_Introduction/01_032_Verify_the_Environment.log
    ```

## Navigation

<!-- startnav -->
* [01 Workshop Introduction / 01 031 Access the Environment](/01_Workshop_Introduction/01_031_Access_the_Environment.md)
* [01 Workshop Introduction / 01 032 Verify the Environment](/01_Workshop_Introduction/01_032_Verify_the_Environment.md)
* [01 Workshop Introduction / 01 999 Fast track with cheatcodes](/01_Workshop_Introduction/01_999_Fast_track_with_cheatcodes.md)**<-- you are here**
* [02 OpenShift Introduction / 02 051 Explore OpenShift](/02_OpenShift_Introduction/02_051_Explore_OpenShift.md)
* [04 Deployment / 04 071 Perform the Prerequisites](/04_Deployment/04_071_Perform_the_Prerequisites.md)
* [04 Deployment / 04 072 Prepare for Viya Deployment](/04_Deployment/04_072_Prepare_for_Viya_Deployment.md)
* [04 Deployment / 04 073 Prepare for OpenShift](/04_Deployment/04_073_Prepare_for_OpenShift.md)
* [04 Deployment / 04 074 Customize Viya Deployment](/04_Deployment/04_074_Customize_Viya_Deployment.md)
* [04 Deployment / 04 075 Manually Deploy Viya](/04_Deployment/04_075_Manually_Deploy_Viya.md)
* [05 Deployment Customizations / 05 021 Provision Temp Storage](/05_Deployment_Customizations/05_021_Provision_Temp_Storage.md)
* [05 Deployment Customizations / 05 022 Customize CASDISKCACHE](/05_Deployment_Customizations/05_022_Customize_CASDISKCACHE.md)
* [09 The End / 09 999 Cleanup](/09_The_End/09_999_Cleanup.md)
<!-- endnav -->
