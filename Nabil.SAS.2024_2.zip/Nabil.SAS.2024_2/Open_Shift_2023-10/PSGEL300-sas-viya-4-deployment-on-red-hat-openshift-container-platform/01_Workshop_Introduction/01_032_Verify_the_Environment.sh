kubectl version --client --short
kustomize version
jq --version
oc version --client
az version
az account show
if [[ $? == 1 ]]; then
gatedemo003Pass=$(cat /home/cloud-user/azureADusers.txt|grep 'gatedemo003'|awk -F'::' '{print $2}')
az login -u gatedemo003@gelenable.sas.com -p "$gatedemo003Pass"
fi
az account set -s "PSGEL300 SAS Viya Deploy Red Hat OpenShift"
