![Global Enablement & Learning](https://gelgitlab.race.sas.com/GEL/utilities/writing-content-in-markdown/-/raw/master/img/gel_banner_logo_tech-partners.jpg)

# PSGEL300: SAS Viya 4 - Deployment on Red Hat OpenShift Container Platform

```yaml
Cadence : lts
Version : 2023.10
OpenShift Container Platform version : 4.14
```

This class will cover tasks that are specific to deploying the SAS Viya platform on Red Hat OpenShift Container Platform (OCP).

See the [index.mkd](index.mkd) file for workshop information.
