#!/bin/bash
###############################################################################
#        Name: GEL.037.Create.StorageAccounts                                 #
# Description: Create the storage accounts used by OCP and by SAS Viya        #
# --------------------------------------------------------------------------- #
# Edoardo Riva,        Initial release,                              OCT-2023 #
###############################################################################
#set -x

# Get common collateral ------------------------------------------------
FUNCTION_FILE=/opt/gellow_code/scripts/common/common_functions.shinc
source <( cat ${FUNCTION_FILE}  )

# only run when part of the PSGEL300 workshop
if [[ "${GIT_WKSHP_CODE^^}" != "${GELENABLE_WORKSHOP_CODE}" ]]; then exit; fi

createStorageAccountOCP () {
    # See https://docs.openshift.com/container-platform/4.14/installing/installing_azure/installing-azure-user-infra.html#installation-azure-user-infra-uploading-rhcos_installing-azure-user-infra
    logit "creating Azure Storage Account for OCP (Blob) : ${AZURE_SA_OCP}"
    az storage account create -g "${AZURE_INFRA_RG}" --location "${AZURE_REGION}" \
        --name "${AZURE_SA_OCP}" \
        --kind Storage \
        --sku Standard_LRS
}

createStorageAccountViya () {
    # Create a storage account suitable for NFS RWX csi access.
    # See http://sww.sas.com/blogs/wp/gate/80437/using-azure-files-for-storage-with-sas-viya/snzmgo/2023/08/02
    logit "creating Azure Storage Account for SAS Viya (Premium File) : ${AZURE_SA_VIYA}"
    # NFS access to Azure Files requires:
    # - FileStorage kind with Premium sku
    # - https not enforced
    # - endpoints not reachable from the web (--default-action Deny + explicit network rules, or --public-network-access disabled + private endpoint)
    # See https://charbelnemnom.com/getting-started-with-nfs-v4-1-for-azure-files/#Prerequisites
    az storage account create -g "${AZURE_INFRA_RG}" --location "${AZURE_REGION}" \
        --name "${AZURE_SA_VIYA}" \
        --kind FileStorage \
        --sku Premium_LRS \
        --default-action Deny \
        --https-only false
    # Grant access to Microsoft.Storage service endpoints defined on the control and workers vnets
    # See https://learn.microsoft.com/en-us/azure/storage/common/storage-network-security?toc=%2Fazure%2Fstorage%2Fblobs%2Ftoc.json&bc=%2Fazure%2Fstorage%2Fblobs%2Fbreadcrumb%2Ftoc.json&tabs=azure-cli#grant-access-from-a-virtual-network
    subnetid=$(az network vnet subnet show -g "${AZURE_INFRA_RG}" --vnet-name "${AZURE_INFRA_RG}-vnet" --name "${AZURE_INFRA_RG}-controlPlane-subnet" --query id --output tsv)
    az storage account network-rule add -g "${AZURE_INFRA_RG}" --account-name "${AZURE_SA_VIYA}" --subnet "$subnetid"
    subnetid=$(az network vnet subnet show -g "${AZURE_INFRA_RG}" --vnet-name "${AZURE_INFRA_RG}-vnet" --name "${AZURE_INFRA_RG}-worker-subnet" --query id --output tsv)
    az storage account network-rule add -g "${AZURE_INFRA_RG}" --account-name "${AZURE_SA_VIYA}" --subnet "$subnetid"
}

validateStorageAccount () {
    validate -t 60s -s 5 -c "az storage account show -g ${AZURE_INFRA_RG} --name $1 --query provisioningState"
    if [ $? -ne 0 ]; then
        notifyandabort "ERROR: Failure creating Storage Account ${AZURE_SA_OCP}"
        return ${_ABORT_CODE}
    fi
}

deleteStorageAccount () {
    logit "deleting Azure Storage Account $1"
    az storage account delete --name "$1" -y
}

case "$1" in
    'enable')
    ;;
    'start')
        if isFirstHost ; then
            createStorageAccountOCP
            createStorageAccountViya
            validateStorageAccount "${AZURE_SA_OCP}"
            validateStorageAccount "${AZURE_SA_VIYA}"
        fi
    ;;
    'stop')
    ;;
    'clean')
        if isFirstHost ; then
            deleteStorageAccount "${AZURE_SA_OCP}"
            deleteStorageAccount "${AZURE_SA_VIYA}"
        fi
    ;;
    'update')
    ;;
    'validate')
        if isFirstHost ; then
            validateStorageAccount "${AZURE_SA_OCP}"
            validateStorageAccount "${AZURE_SA_VIYA}"
        fi
    ;;
    'list')
    ;;
    *)
        printf '\nThe parameter %s does not do anything in the script %s \n' "$1" "$(basename "$0")"
        exit 1
    ;;
esac