#!/bin/bash
###############################################################################
#        Name: Install Kubectl CLI                                            #
# Description: Installs the kubectl CLI on the RACE linus client              #
#              This used to be done automatically by gellow, now has to be    #
#              explictly done here                                            #
# --------------------------------------------------------------------------- #
# Edoardo Riva,        Initial release,                              JUL-2023 #
###############################################################################
#set -x

# Get common collateral ------------------------------------------------
FUNCTION_FILE=/opt/gellow_code/scripts/common/common_functions.shinc
source <( cat ${FUNCTION_FILE}  )

# only run when part of the PSGEL300 workshop
if [[ "${GIT_WKSHP_CODE^^}" != "PSGEL300" ]]; then exit; fi

case "$1" in
    'enable')
    ;;
    'start')
        bash -E ${CODE_DIR}/scripts/loop/viya4/GEL.0060.Install.Kubectl.sh start
    ;;
    'stop')
    ;;
    'clean')
        bash -E ${CODE_DIR}/scripts/loop/viya4/GEL.0060.Install.Kubectl.sh clean
    ;;
    'update')
    ;;
    'validate')
    ;;
    'list')
    ;;
    *)
        printf '\nThe parameter %s does not do anything in the script %s \n' "$1" "$(basename "$0")"
        exit 1
    ;;
esac