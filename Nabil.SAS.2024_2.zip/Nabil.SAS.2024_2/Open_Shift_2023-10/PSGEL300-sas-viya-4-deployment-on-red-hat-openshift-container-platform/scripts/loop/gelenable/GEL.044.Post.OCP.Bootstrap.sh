#!/bin/bash
###############################################################################
#        Name: GEL.044.Post.OCP.Bootstrap                                     #
# Description: Wait for the control plane to ready, then delete               #
#              bootstrap resources                                            #
# See https://docs.openshift.com/container-platform/4.7/installing/installing_azure/installing-azure-user-infra.html#installation-azure-user-infra-wait-for-bootstrap_installing-azure-user-infra #
# --------------------------------------------------------------------------- #
# Edoardo Riva,        Initial release,                              OCT-2021 #
#                      Workaround to get 4.14 bootstrap              JAN-2024 #
###############################################################################
#set -x

# Get common collateral ------------------------------------------------
FUNCTION_FILE=/opt/gellow_code/scripts/common/common_functions.shinc
source <( cat ${FUNCTION_FILE}  )
source <( cat /opt/gellow_work/vars/vars.txt )

# only run when part of the PSGEL300 workshop
if [[ "${GIT_WKSHP_CODE^^}" != "PSGEL300" ]]; then exit; fi

# location where OCP manifests reside
CLUSTERCONF_DIR=/home/cloud-user/project/clusterconfig
KUBECONFIG=${CLUSTERCONF_DIR}/auth/kubeconfig

waitForCluster () {
    logit "Waiting until OCP bootstrap is finished - up to 50 minutes"
    openshift-install wait-for bootstrap-complete --dir=${CLUSTERCONF_DIR} \
    --log-level info
    [ $? -ne 0 ] && notifyandabort "ERROR: Openshift bootstrap may have failed or it may be impossible to connect to it" && return ${_ABORT_CODE}
    logit "Done waiting. OCP bootstrap should be finished"
}

waitForCluster2 () {
    # According to OCP instructions, running `openshift-install wait-for bootstrap-complete` to check and wait should be
    # enough. Unfurtunately, starting with OCP 4.14, the Cloud Controller Manager in our env has issues registering the
    # control plane nodes and they timeout and get evicted. Then, "wait-for bootstrap-complete" just fails.
    # This function automates a manual workround: restarting the control plane nodes, maybe a few times, seems to consistently get past the block.

    # Step 1 Use CURL to mimic the 1st step of `openshift-install wait-for bootstrap-complete`
    API_URL="https://api.${CLUSTER_NAME}.${BASE_DOMAIN}:443"
    logit "Waiting up to 15 minutes for the Kubernetes API at ${API_URL} ..."
    _api_OK=${_ABORT_CODE}
    for i in {1..15}
    do
        if curl -k -s -m 2 "${API_URL}/version" -o /dev/null; then
            _api_OK=0
            logit "$PASS Kubernetes API is responsive"
            break
        fi
        logit " ... waiting ${i} ..."
        sleep 58
    done
    # exit on error
    [ $_api_OK == 0 ] || (notifyandabort "ERROR: Openshift bootstrap may have failed or it may be impossible to connect to it" && return ${_ABORT_CODE})

    # Step 2 check if the control plane nodes are ready
    # When the control planes initialy appear in the API, they may take some time to become ready.
    # After 3 minutes the bootstap removes the machines if they are still not ready and all stops there.
    # Manual workaround: Wait 5 minutes for nodes to come and stay online, otherwise reboot the virtual machines
    #  repet the workaround up to 4 times, otherwise give up.
    for t in {1..4}
    do
        logit "Waiting 5 minutes for the control plane nodes to register with the Kubernetes API ..."
        _num_nodes=0
        for i in {1..5}
        do
            _num_nodes=$(oc --kubeconfig ${KUBECONFIG} get nodes | grep -c "control-plane")
            logit " ... found ${_num_nodes} nodes. Waiting ${i} of 5"
            sleep 60
        done
        _num_nodes=$(oc --kubeconfig ${KUBECONFIG} get nodes | grep -c "control-plane")
        if (( $_num_nodes < 3 )); then
            logit "Some control plane nodes have been evicted. Rebooting machines to fix it (this may take a few minutes)"
            az vm restart --ids $(az vm list -g ${AZURE_INFRA_RG} --query "[].id" -o tsv | grep controlPlane)
        else
           break
        fi
        logit "Control plane nodes still not registered after $t loop(s)"
    done

    # When we get here, either control plane machines have not been evicted for more than 5 minutes (good!)
    # or the check timed out after 20 minutes. Let's check and handle which of the 2 cases it is.
    _num_nodes=$(oc --kubeconfig ${KUBECONFIG} get nodes | grep -c "control-plane")
    if (( $_num_nodes < 3 )); then
        # exit on error
        notifyandabort "ERROR: Openshift bootstrap may have failed or it may be impossible to connect to it"
        return ${_ABORT_CODE}
    fi
    # now it should be safe to do the normal "wait"
    waitForCluster
}

deleteBootstrap () {
    logit "Deleting OCP bootstrap artifacts"
    DELETESCRIPT=$(find "$(dirname $0)" -iname *create*ocp*bootstrap* -xtype f)
    bash ${DELETESCRIPT} clean
}

case "$1" in
    'enable')
    ;;
    'start')
        if isFirstHost ; then
            waitForCluster2
            # abort only if the function aborted
            [[ $? == ${_ABORT_CODE} ]] && exit ${_ABORT_CODE}
            deleteBootstrap
        fi
    ;;
    'stop')
    ;;
    'clean')
    ;;
    'update')
    ;;
    'validate')
    ;;
    'list')
    ;;
    *)
        printf '\nThe parameter %s does not do anything in the script %s \n' "$1" "$(basename "$0")"
        exit 1
    ;;
esac